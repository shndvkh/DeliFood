<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_messages':
        if (!isLoggedIn()) {
            echo json_encode(['success' => false, 'error' => 'Требуется авторизация']);
            exit;
        }
        
        $userId = $_SESSION['user_id'];
        $lastId = isset($_GET['last_id']) ? intval($_GET['last_id']) : 0;
        
        $db = getDB();
        
        if ($lastId > 0) {
            $stmt = $db->prepare("
                SELECT * FROM chat_messages 
                WHERE (user_id = ? OR user_id IS NULL) 
                AND id > ?
                ORDER BY created_at ASC
            ");
            $stmt->execute([$userId, $lastId]);
        } else {
            $stmt = $db->prepare("
                SELECT * FROM chat_messages 
                WHERE user_id = ? OR user_id IS NULL 
                ORDER BY created_at ASC
                LIMIT 50
            ");
            $stmt->execute([$userId]);
        }
        
        $messages = $stmt->fetchAll();
        echo json_encode(['success' => true, 'messages' => $messages]);
        break;
        
    case 'send_message':
        if (!isLoggedIn()) {
            echo json_encode(['success' => false, 'error' => 'Требуется авторизация']);
            exit;
        }
        
        $data = json_decode(file_get_contents('php://input'), true);
        $message = sanitize($data['message'] ?? '');
        $userId = $_SESSION['user_id'];
        $isAdmin = false;
        
        if (empty($message)) {
            echo json_encode(['success' => false, 'error' => 'Сообщение не может быть пустым']);
            exit;
        }
        
        $db = getDB();
        
        // Обновляем время последнего сообщения в чат-комнате
        $stmt = $db->prepare("
            UPDATE chat_rooms 
            SET last_message_at = NOW() 
            WHERE user_id = ?
        ");
        $stmt->execute([$userId]);
        
        // Сохраняем сообщение
        $stmt = $db->prepare("
            INSERT INTO chat_messages (user_id, message, is_admin, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        
        if ($stmt->execute([$userId, $message, $isAdmin])) {
            // Отправляем уведомление администратору (можно добавить WebSocket или email)
            notifyAdmin($userId, $message, $db);
            
            echo json_encode(['success' => true, 'message_id' => $db->lastInsertId()]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Ошибка отправки сообщения']);
        }
        break;
        
    case 'mark_read':
        if (!isLoggedIn()) {
            echo json_encode(['success' => false, 'error' => 'Требуется авторизация']);
            exit;
        }
        
        $userId = $_SESSION['user_id'];
        $db = getDB();
        
        $stmt = $db->prepare("
            UPDATE chat_messages 
            SET is_read = TRUE 
            WHERE user_id = ? AND is_admin = TRUE AND is_read = FALSE
        ");
        $stmt->execute([$userId]);
        
        echo json_encode(['success' => true]);
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Неизвестное действие']);
}

// Функция для уведомления администратора
function notifyAdmin($userId, $message, $db) {
    // Можно реализовать:
    // 1. WebSocket уведомление
    // 2. Email уведомление
    // 3. Запись в лог
    
    // Для простоты просто логируем
    error_log("Новое сообщение в чате от пользователя $userId: $message");
    
    // Получаем информацию о пользователе
    $stmt = $db->prepare("SELECT name, email FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Можно отправить email администратору
        $adminEmail = 'admin@dostavka-lyantor.ru';
        $subject = 'Новое сообщение в чате поддержки';
        $body = "Пользователь: {$user['name']} ({$user['email']})\n";
        $body .= "Сообщение: $message\n\n";
        $body .= "Ссылка для ответа: " . BASE_URL . "/admin/?action=chat&user_id=$userId";
        
        // mail($adminEmail, $subject, $body);
    }
}
?>