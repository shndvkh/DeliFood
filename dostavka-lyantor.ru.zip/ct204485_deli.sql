-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Server version: 8.0.43-34
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ct204485_deli`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Пицца'),
(2, 'Суши'),
(3, 'Бургеры'),
(4, 'Салаты'),
(5, 'Напитки'),
(6, 'Десерты');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE IF NOT EXISTS `dishes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL,
  `restaurant_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`id`, `name`, `description`, `price`, `restaurant_id`, `category_id`, `image`, `active`, `created_at`) VALUES
(1, 'Пицца Пепперони', 'Классика с салями', 750.00, 1, 1, 'pepperoni.jpg', 1, '2025-12-05 11:40:30'),
(2, 'Ролл Филадельфия', 'Лосось, сыр, огурец', 480.00, 2, 2, 'philadelphia.jpg', 1, '2025-12-05 11:40:30'),
(3, 'Чизбургер', 'Сочный бургер с сыром', 520.00, 3, 3, 'cheeseburger.jpg', 1, '2025-12-05 11:40:30'),
(4, 'Салат Цезарь', 'С курицей и соусом', 390.00, 4, 4, 'caesar.jpg', 1, '2025-12-05 11:40:30'),
(5, 'Пицца 4 сыра', 'Моцарелла, горгонзола, пармезан, эмменталь', 820.00, 1, 1, 'four-cheese.jpg', 1, '2025-12-05 11:40:30'),
(6, 'Ролл Калифорния', 'Краб, авокадо, огурец', 450.00, 2, 2, 'california.jpg', 1, '2025-12-05 11:40:30'),
(7, 'Бургер с беконом', 'С беконом и сыром чеддер', 580.00, 3, 3, 'bacon-burger.jpg', 1, '2025-12-05 11:40:30'),
(8, 'Греческий салат', 'С фетой и оливками', 40.00, 4, 4, 'greek-salad.jpg', 1, '2025-12-05 11:40:30'),
(10, 'кофеек латте', '', 35.00, 9, 5, 'coffee.jpg', 1, '2025-12-06 10:48:51');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `restaurant_id` int DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `delivery_address` text NOT NULL,
  `delivery_time` varchar(50) DEFAULT NULL,
  `payment_method` varchar(20) DEFAULT NULL,
  `status` enum('pending','processing','delivering','delivered','cancelled') DEFAULT 'pending',
  `comment` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `dish_id` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE IF NOT EXISTS `restaurants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `cuisine` varchar(50) DEFAULT NULL,
  `rating` decimal(3,1) DEFAULT '0.0',
  `image` varchar(255) DEFAULT NULL,
  `delivery_time` varchar(20) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `name`, `description`, `cuisine`, `rating`, `image`, `delivery_time`, `active`, `created_at`) VALUES
(1, 'Пиццерия \"Маргарита\"', NULL, 'Итальянская кухня', 5.0, 'pizza.jpg', '20-30 мин', 1, '2025-12-05 11:40:30'),
(2, 'Суши-бар \"Сакура\"', NULL, 'Японская кухня', 5.0, 'sushi.jpg', '25-30 мин', 1, '2025-12-05 11:40:30'),
(3, 'Бургерная \"Гриль\"', NULL, 'Американская кухня', 4.5, 'burgers.jpg', '25-30 мин', 1, '2025-12-05 11:40:30'),
(4, 'Кафе \"Уют\"', NULL, 'Европейская кухня', 5.0, 'cafe.jpg', '35-45 мин', 1, '2025-12-05 11:40:30'),
(9, 'Кафе \"Кофе\"', '', 'Домашняя кухня', 0.0, NULL, '10-15 мин', 1, '2025-12-06 10:48:18');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `restaurant_id` int DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `comment` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `restaurant_id`, `order_id`, `rating`, `comment`, `created_at`) VALUES
(1, 1, 3, NULL, 5, 'Лучшая бургерная, которая только есть в нашем городе!', '2025-12-06 11:33:18'),
(2, 1, 3, NULL, 4, 'Сойдет.                            ⠀⠀⠀⠀⠀', '2025-12-06 11:34:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `address`, `created_at`) VALUES
(1, 'Admin', 'admin@dostavka-lyantor.ru', '$2y$10$qlcKFAFLuDFr5LrU6MbhD.0Y6npoTiytcyqTVRgVkGPmEqCqto83u', '', NULL, '2024-12-31 21:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
