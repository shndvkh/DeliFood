<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$address = isset($_GET['address']) ? sanitize($_GET['address']) : '';

if (empty($address)) {
    echo json_encode(['success' => false, 'error' => 'Адрес не указан']);
    exit;
}

$db = getDB();

// В реальном приложении здесь был бы геокодинг адреса
// и поиск ресторанов в радиусе доставки

// Для демонстрации просто возвращаем все активные рестораны
$stmt = $db->query("SELECT * FROM restaurants WHERE active = TRUE ORDER BY rating DESC LIMIT 10");
$restaurants = $stmt->fetchAll();

// Добавляем информацию о доставке
foreach ($restaurants as &$restaurant) {
    // В реальном приложении здесь рассчитывалось бы время доставки
    // на основе расстояния и зоны доставки
    $restaurant['estimated_delivery'] = $restaurant['delivery_time'];
    $restaurant['delivery_fee'] = 200; // Стандартная плата за доставку
}

echo json_encode([
    'success' => true,
    'address' => $address,
    'restaurants' => $restaurants,
    'count' => count($restaurants),
    'message' => 'Найдено ' . count($restaurants) . ' ресторанов'
]);
?>