<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Требуется авторизация']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Неверный метод запроса']);
    exit;
}

$userId = $_SESSION['user_id'];
$restaurantId = isset($_POST['restaurant_id']) ? intval($_POST['restaurant_id']) : 0;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
$comment = isset($_POST['comment']) ? sanitize($_POST['comment']) : '';

// Валидация
if ($rating < 1 || $rating > 5) {
    echo json_encode(['success' => false, 'error' => 'Рейтинг должен быть от 1 до 5']);
    exit;
}

if (empty($comment) || strlen($comment) < 20) {
    echo json_encode(['success' => false, 'error' => 'Отзыв должен содержать минимум 20 символов']);
    exit;
}

if (strlen($comment) > 1000) {
    echo json_encode(['success' => false, 'error' => 'Отзыв не должен превышать 1000 символов']);
    exit;
}

$db = getDB();

// Проверка лимита отзывов на сегодня
$stmt = $db->prepare("
    SELECT COUNT(*) as today_reviews 
    FROM reviews 
    WHERE user_id = ? 
    AND DATE(created_at) = CURDATE()
");
$stmt->execute([$userId]);
$todayReviews = $stmt->fetch()['today_reviews'];

if ($todayReviews >= 3) {
    echo json_encode(['success' => false, 'error' => 'Вы превысили лимит отзывов на сегодня (3)']);
    exit;
}

// Проверка существования ресторана (если указан)
if ($restaurantId > 0) {
    $stmt = $db->prepare("SELECT id FROM restaurants WHERE id = ? AND active = TRUE");
    $stmt->execute([$restaurantId]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Ресторан не найден']);
        exit;
    }
    
    // Проверка, не оставлял ли пользователь уже отзыв на этот ресторан
    $stmt = $db->prepare("
        SELECT id 
        FROM reviews 
        WHERE user_id = ? 
        AND restaurant_id = ?
        LIMIT 1
    ");
    $stmt->execute([$userId, $restaurantId]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Вы уже оставляли отзыв для этого ресторана']);
        exit;
    }
}

// Добавление отзыва
$stmt = $db->prepare("
    INSERT INTO reviews (user_id, restaurant_id, rating, comment, created_at)
    VALUES (?, ?, ?, ?, NOW())
");

if ($stmt->execute([$userId, $restaurantId > 0 ? $restaurantId : null, $rating, $comment])) {
    // Обновляем средний рейтинг ресторана (если отзыв с рестораном)
    if ($restaurantId > 0) {
        updateRestaurantRating($restaurantId, $db);
    }
    
    echo json_encode(['success' => true, 'message' => 'Отзыв успешно добавлен']);
} else {
    echo json_encode(['success' => false, 'error' => 'Ошибка при добавлении отзыва']);
}

// Функция для обновления рейтинга ресторана
function updateRestaurantRating($restaurantId, $db) {
    $stmt = $db->prepare("
        SELECT AVG(rating) as avg_rating 
        FROM reviews 
        WHERE restaurant_id = ? 
        AND rating IS NOT NULL
    ");
    $stmt->execute([$restaurantId]);
    $result = $stmt->fetch();
    
    if ($result && $result['avg_rating']) {
        $updateStmt = $db->prepare("UPDATE restaurants SET rating = ? WHERE id = ?");
        $updateStmt->execute([round($result['avg_rating'], 1), $restaurantId]);
    }
}
?>