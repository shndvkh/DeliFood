        </div>
    </div>
    
    <footer class="site-footer">
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Админ-панель</p>
            </div>
        </div>
    </footer>
    
    <script src="<?php echo ASSETS_URL; ?>/assets/js/script.js"></script>
</body>
</html>