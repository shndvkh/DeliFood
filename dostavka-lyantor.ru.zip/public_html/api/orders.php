<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Требуется авторизация']);
    exit;
}

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$userId = $_SESSION['user_id'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $stmt = $db->prepare("
                SELECT o.*, r.name as restaurant_name 
                FROM orders o 
                LEFT JOIN restaurants r ON o.restaurant_id = r.id 
                WHERE o.id = ? AND o.user_id = ?
            ");
            $stmt->execute([$_GET['id'], $userId]);
            $order = $stmt->fetch();
            
            if ($order) {
                // Получаем элементы заказа
                $stmt = $db->prepare("
                    SELECT oi.*, d.name as dish_name, d.image 
                    FROM order_items oi 
                    LEFT JOIN dishes d ON oi.dish_id = d.id 
                    WHERE oi.order_id = ?
                ");
                $stmt->execute([$_GET['id']]);
                $order['items'] = $stmt->fetchAll();
                
                echo json_encode($order);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Заказ не найден']);
            }
        } else {
            $stmt = $db->prepare("
                SELECT o.*, r.name as restaurant_name 
                FROM orders o 
                LEFT JOIN restaurants r ON o.restaurant_id = r.id 
                WHERE o.user_id = ? 
                ORDER BY o.created_at DESC
            ");
            $stmt->execute([$userId]);
            $orders = $stmt->fetchAll();
            echo json_encode($orders);
        }
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['items']) || empty($data['items'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Корзина пуста']);
            exit;
        }
        
        try {
            $db->beginTransaction();
            
            // Определяем ресторан
            $firstItem = $data['items'][0];
            $stmt = $db->prepare("SELECT restaurant_id FROM dishes WHERE id = ?");
            $stmt->execute([$firstItem['dish_id']]);
            $dish = $stmt->fetch();
            $restaurantId = $dish['restaurant_id'];
            
            // Рассчитываем общую сумму
            $totalAmount = 0;
            foreach ($data['items'] as $item) {
                $stmt = $db->prepare("SELECT price FROM dishes WHERE id = ?");
                $stmt->execute([$item['dish_id']]);
                $dish = $stmt->fetch();
                $totalAmount += $dish['price'] * $item['quantity'];
            }
            
            // Добавляем стоимость доставки
            $totalAmount += 200;
            
            // Создаем заказ
            $stmt = $db->prepare("
                INSERT INTO orders (
                    user_id, restaurant_id, total_amount, 
                    delivery_address, delivery_time, 
                    payment_method, status, comment
                ) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
            ");
            
            $stmt->execute([
                $userId,
                $restaurantId,
                $totalAmount,
                $data['address'],
                $data['delivery_time'],
                $data['payment_method'],
                $data['comment'] ?? ''
            ]);
            
            $orderId = $db->lastInsertId();
            
            // Добавляем элементы заказа
            $stmt = $db->prepare("
                INSERT INTO order_items (order_id, dish_id, quantity, price)
                VALUES (?, ?, ?, ?)
            ");
            
            foreach ($data['items'] as $item) {
                $stmt = $db->prepare("SELECT price FROM dishes WHERE id = ?");
                $stmt->execute([$item['dish_id']]);
                $dish = $stmt->fetch();
                
                $stmt = $db->prepare("INSERT INTO order_items (order_id, dish_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->execute([$orderId, $item['dish_id'], $item['quantity'], $dish['price']]);
            }
            
            $db->commit();
            
            echo json_encode([
                'success' => true,
                'order_id' => $orderId,
                'message' => 'Заказ успешно создан'
            ]);
            
        } catch (Exception $e) {
            $db->rollBack();
            http_response_code(500);
            echo json_encode(['error' => 'Ошибка при создании заказа: ' . $e->getMessage()]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Метод не поддерживается']);
        break;
}
?>