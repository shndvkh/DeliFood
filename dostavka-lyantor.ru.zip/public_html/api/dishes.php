<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$db = getDB();

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $db->prepare("SELECT d.*, r.name as restaurant_name FROM dishes d LEFT JOIN restaurants r ON d.restaurant_id = r.id WHERE d.id = ? AND d.active = TRUE");
    $stmt->execute([$id]);
    $dish = $stmt->fetch();
    
    if ($dish) {
        echo json_encode($dish);
    } else {
        echo json_encode(['error' => 'Dish not found']);
    }
} else {
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    $stmt = $db->prepare("
        SELECT d.*, r.name as restaurant_name 
        FROM dishes d 
        LEFT JOIN restaurants r ON d.restaurant_id = r.id 
        WHERE d.active = TRUE 
        ORDER BY d.id DESC 
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$limit, $offset]);
    $dishes = $stmt->fetchAll();
    echo json_encode($dishes);
}
?>