<?php
$pageTitle = 'Доставка еды на дом';
require_once __DIR__ . '/includes/header.php';

$db = getDB();

$stmt = $db->query("
    SELECT r.*, 
           COALESCE(AVG(rev.rating), 0) as real_rating,
           COUNT(rev.id) as reviews_count
    FROM restaurants r
    LEFT JOIN reviews rev ON r.id = rev.restaurant_id
    WHERE r.active = TRUE
    GROUP BY r.id
    ORDER BY real_rating DESC, r.id DESC
");
$allRestaurants = $stmt->fetchAll();

$restaurants = [];
$usedIds = [];

foreach ($allRestaurants as $restaurant) {
    if (!in_array($restaurant['id'], $usedIds)) {
        $usedIds[] = $restaurant['id'];
        $restaurants[] = $restaurant;
    }
}

foreach ($restaurants as &$restaurant) {
    $restaurant['display_rating'] = number_format($restaurant['real_rating'], 1);
    $restaurant['reviews_text'] = getReviewsText($restaurant['reviews_count']);
}
unset($restaurant);

$stmt = $db->query("SELECT d.*, r.name as restaurant_name FROM dishes d LEFT JOIN restaurants r ON d.restaurant_id = r.id WHERE d.active = TRUE");
$dishes = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title">Доставка еды в Лянторе до 30 минут</h1>
            <form method="GET" action="search.php" class="hero-search">
                <input type="text" name="address" class="search-input" 
                       placeholder="Введите адрес в Лянторе..." required>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Найти рестораны
                </button>
            </form>
            <div class="popular-addresses" style="margin-top: 20px; color: rgba(255,255,255,0.8);">
                <span>Популярные адреса в Лянторе: </span>
                <a href="search.php?address=г. Лянтор, Центр" style="color: white; margin: 0 10px;">Центр</a>
                <a href="search.php?address=г. Лянтор, 2-й микрорайон" style="color: white; margin: 0 10px;">2-й микрорайон</a>
                <a href="search.php?address=г. Лянтор, ул. Ленина" style="color: white; margin: 0 10px;">ул. Ленина</a>
            </div>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="section how-it-works">
    <div class="container">
        <h2 class="section-title">Как это работает</h2>
        <div class="steps">
            <div class="step">
                <div class="step-icon">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
                <h3>Выберите адрес</h3>
                <p>Введите ваш адрес доставки</p>
            </div>
            <div class="step">
                <div class="step-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <h3>Выберите блюдо</h3>
                <p>Выберите из более 1000 блюд</p>
            </div>
            <div class="step">
                <div class="step-icon">
                    <i class="fas fa-credit-card"></i>
                </div>
                <h3>Оплатите заказ</h3>
                <p>Онлайн или при получении</p>
            </div>
            <div class="step">
                <div class="step-icon">
                    <i class="fas fa-truck"></i>
                </div>
                <h3>Получите заказ</h3>
                <p>Быстрая доставка до 30 минут</p>
            </div>
        </div>
    </div>
</section>

<!-- Restaurants -->
<section class="section restaurants" id="restaurants">
    <div class="container">
        <h2 class="section-title">Популярные рестораны</h2>
        <?php if (empty($restaurants)): ?>
            <div class="no-restaurants">
                <p>Рестораны временно недоступны. Пожалуйста, зайдите позже.</p>
            </div>
        <?php else: ?>
            <div class="restaurants-grid">
                <?php foreach ($restaurants as $restaurant): ?>
                <div class="restaurant-card">
                    <!-- УБРАЛ ИЗОБРАЖЕНИЕ РЕСТОРАНА -->
                    <div class="restaurant-info">
                        <h3><?php echo htmlspecialchars($restaurant['name']); ?></h3>
                        <p><?php echo htmlspecialchars($restaurant['cuisine']); ?></p>
                        <div class="restaurant-meta">
                            <span class="rating">
                                <i class="fas fa-star"></i> 
                                <?php echo $restaurant['display_rating']; ?>
                                <span class="reviews-count">(<?php echo $restaurant['reviews_text']; ?>)</span>
                            </span>
                            <span class="delivery-time">
                                <i class="fas fa-clock"></i> <?php echo $restaurant['delivery_time']; ?>
                            </span>
                        </div>
                        <a href="restaurant.php?id=<?php echo $restaurant['id']; ?>" class="btn btn-outline">Смотреть меню</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Dishes -->
<section class="section dishes" id="dishes">
    <div class="container">
        <h2 class="section-title">Популярные блюда</h2>
        <?php if (empty($dishes)): ?>
            <div class="no-dishes">
                <p>Блюда временно недоступны. Пожалуйста, зайдите позже.</p>
            </div>
        <?php else: ?>
            <div class="dishes-grid">
                <?php foreach ($dishes as $dish): ?>
                <div class="dish-card">
                    <div class="dish-image">
                        <img src="<?php echo ASSETS_URL; ?>/assets/img/dishes/<?php echo $dish['image'] ?: 'default.jpg'; ?>" alt="<?php echo htmlspecialchars($dish['name']); ?>">
                    </div>
                    <div class="dish-info">
                        <h3><?php echo htmlspecialchars($dish['name']); ?></h3>
                        <p><?php echo htmlspecialchars($dish['description']); ?></p>
                        <div class="dish-footer">
                            <span class="price"><?php echo formatPrice($dish['price']); ?></span>
                            <button class="btn btn-primary cart-button" data-id="<?php echo $dish['id']; ?>">
                                <i class="fas fa-plus"></i> В корзину
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Benefits -->
<section class="section benefits">
    <div class="container">
        <h2 class="section-title">Почему выбирают нас</h2>
        <div class="benefits-grid">
            <div class="benefit">
                <i class="fas fa-bolt"></i>
                <h3>Быстрая доставка</h3>
                <p>Доставка до 30 минут</p>
            </div>
            <div class="benefit">
                <i class="fas fa-shield-alt"></i>
                <h3>Безопасная оплата</h3>
                <p>Оплата онлайн или наличными</p>
            </div>
            <div class="benefit">
                <i class="fas fa-star"></i>
                <h3>Гарантия качества</h3>
                <p>Только свежие продукты</p>
            </div>
        </div>
    </div>
</section>

<!-- Download App -->
<section class="section download-app">
    <div class="container">
        <div class="app-content">
            <div class="app-text">
                <h2>Скачайте наше приложение</h2>
                <p>Заказывайте еду ещё быстрее с нашим мобильным приложением. Доступно для iOS и Android.</p>
                <div class="app-buttons">
                    <a href="#" class="btn btn-dark">
                        <i class="fab fa-apple"></i> App Store
                    </a>
                    <a href="#" class="btn btn-dark">
                        <i class="fab fa-google-play"></i> Google Play
                    </a>
                </div>
            </div>
            <div class="app-image">
                <img src="<?php echo ASSETS_URL; ?>/assets/img/app-screen.png" alt="Мобильное приложение">
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>