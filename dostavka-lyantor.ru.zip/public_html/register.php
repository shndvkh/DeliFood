<?php
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '/account.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = sanitize($_POST['phone'] ?? '');
    
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Все поля обязательны';
    } elseif (!validateEmail($email)) {
        $error = 'Неверный формат email';
    } elseif ($password !== $confirm_password) {
        $error = 'Пароли не совпадают';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль должен содержать минимум 6 символов';
    } else {
        $db = getDB();
        
        // Проверка существования email
        $stmt = $db->prepare("SELECT id, email FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $error = 'Пользователь с таким email уже зарегистрирован';
        } else {
            $hashedPassword = hashPassword($password);
            
            $stmt = $db->prepare("
                INSERT INTO users (name, email, password, phone, created_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            
            if ($stmt->execute([$name, $email, $hashedPassword, $phone])) {
                $userId = $db->lastInsertId();
                $_SESSION['user_id'] = $userId;
                $_SESSION['user_name'] = $name;
                redirect(BASE_URL . '/account.php');
            } else {
                $error = 'Ошибка при регистрации. Попробуйте еще раз.';
            }
        }
    }
}

$pageTitle = 'Регистрация';
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>Регистрация</h1>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <div class="auth-form">
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="" id="registerForm">
                <div class="form-group">
                    <label for="name">Имя *</label>
                    <input type="text" id="name" name="name" class="form-control" 
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" 
                           required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" class="form-control" 
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                           required>
                    <small class="email-hint" style="display: none; color: #f44336;"></small>
                </div>
                
                <div class="form-group">
                    <label for="phone">Телефон</label>
                    <input type="tel" id="phone" name="phone" class="form-control" 
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль * (минимум 6 символов)</label>
                    <input type="password" id="password" name="password" class="form-control" required minlength="6">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Подтвердите пароль *</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block" id="submitBtn">Зарегистрироваться</button>
                
                <div class="text-center mt-2">
                    <p>Уже есть аккаунт? <a href="<?php echo BASE_URL; ?>/login.php">Войдите</a></p>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('email').addEventListener('blur', function() {
    const email = this.value.trim();
    const emailHint = document.querySelector('.email-hint');
    
    if (!email) {
        emailHint.style.display = 'none';
        return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        emailHint.textContent = 'Неверный формат email';
        emailHint.style.display = 'block';
        document.getElementById('submitBtn').disabled = true;
        return;
    }
    
    fetch('api/check-email.php?email=' + encodeURIComponent(email))
        .then(response => response.json())
        .then(data => {
            if (data.exists) {
                emailHint.textContent = 'Этот email уже зарегистрирован';
                emailHint.style.display = 'block';
                document.getElementById('submitBtn').disabled = true;
            } else {
                emailHint.style.display = 'none';
                document.getElementById('submitBtn').disabled = false;
            }
        })
        .catch(error => {
            console.error('Error checking email:', error);
        });
});

// Проверка совпадения паролей
document.getElementById('confirm_password').addEventListener('input', function() {
    const password = document.getElementById('password').value;
    const confirmPassword = this.value;
    const submitBtn = document.getElementById('submitBtn');
    
    if (password !== confirmPassword) {
        this.style.borderColor = '#f44336';
        submitBtn.disabled = true;
    } else {
        this.style.borderColor = '';
        submitBtn.disabled = false;
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>