<?php
require_once __DIR__ . '/includes/config.php';

$restaurantId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$restaurantId) {
    redirect(BASE_URL . '/');
}

$db = getDB();

$stmt = $db->prepare("
    SELECT r.*, 
           COALESCE(AVG(rev.rating), 0) as real_rating,
           COUNT(rev.id) as reviews_count
    FROM restaurants r
    LEFT JOIN reviews rev ON r.id = rev.restaurant_id
    WHERE r.id = ? AND r.active = TRUE
    GROUP BY r.id
");
$stmt->execute([$restaurantId]);
$restaurant = $stmt->fetch();

if (!$restaurant) {
    redirect(BASE_URL . '/');
}

$restaurant['display_rating'] = number_format($restaurant['real_rating'], 1);
$restaurant['reviews_text'] = getReviewsText($restaurant['reviews_count']);

$stmt = $db->prepare("SELECT * FROM dishes WHERE restaurant_id = ? AND active = TRUE ORDER BY category_id, name");
$stmt->execute([$restaurantId]);
$dishes = $stmt->fetchAll();

$categories = [];
foreach ($dishes as $dish) {
    $categoryId = $dish['category_id'];
    if (!isset($categories[$categoryId])) {
        $stmt = $db->prepare("SELECT name FROM categories WHERE id = ?");
        $stmt->execute([$categoryId]);
        $category = $stmt->fetch();
        $categories[$categoryId] = [
            'name' => $category['name'] ?? 'Без категории',
            'dishes' => []
        ];
    }
    $categories[$categoryId]['dishes'][] = $dish;
}

$pageTitle = $restaurant['name'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <div style="display: flex; align-items: center; gap: 30px;">
            <div>
                <h1><?php echo htmlspecialchars($restaurant['name']); ?></h1>
                <div style="display: flex; gap: 20px; margin-top: 10px; color: #666;">
                    <span class="rating">
                        <i class="fas fa-star" style="color: #FFC107;"></i> 
                        <?php echo $restaurant['display_rating']; ?> (<?php echo $restaurant['reviews_text']; ?>)
                    </span>
                    <span class="delivery-time">
                        <i class="fas fa-clock"></i> <?php echo $restaurant['delivery_time']; ?>
                    </span>
                    <span class="cuisine">
                        <i class="fas fa-utensils"></i> <?php echo htmlspecialchars($restaurant['cuisine']); ?>
                    </span>
                </div>
                <p style="margin-top: 10px;"><?php echo htmlspecialchars($restaurant['description'] ?? ''); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <?php if (empty($categories)): ?>
            <div class="text-center" style="padding: 60px 0;">
                <i class="fas fa-utensils" style="font-size: 80px; color: #ddd; margin-bottom: 20px;"></i>
                <h2>Меню пусто</h2>
                <p>Ресторан временно не принимает заказы.</p>
            </div>
        <?php else: ?>
            <div class="restaurant-menu">
                <?php foreach ($categories as $categoryId => $category): ?>
                <div class="menu-category" id="category-<?php echo $categoryId; ?>">
                    <h2 style="margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #eee;">
                        <?php echo htmlspecialchars($category['name']); ?>
                    </h2>
                    
                    <div class="dishes-grid">
                        <?php foreach ($category['dishes'] as $dish): ?>
                        <div class="dish-card">
                            <div class="dish-image">
                                <img src="<?php echo ASSETS_URL; ?>/assets/img/dishes/<?php echo $dish['image'] ?: 'default.jpg'; ?>" 
                                     alt="<?php echo htmlspecialchars($dish['name']); ?>">
                            </div>
                            <div class="dish-info">
                                <h3><?php echo htmlspecialchars($dish['name']); ?></h3>
                                <p><?php echo htmlspecialchars($dish['description']); ?></p>
                                <div class="dish-footer">
                                    <span class="price"><?php echo formatPrice($dish['price']); ?></span>
                                    <button class="btn btn-primary cart-button" data-id="<?php echo $dish['id']; ?>">
                                        <i class="fas fa-plus"></i> В корзину
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>