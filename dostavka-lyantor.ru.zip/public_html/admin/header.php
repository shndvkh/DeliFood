<?php
// Этот файл НЕ включает стандартный header.php
// Он создает собственный заголовок без вывода, чтобы можно было отправлять заголовки позже
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?><?php echo SITE_NAME; ?> - Админка</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
    /* Стили для админки */
    .admin-container {
        display: flex;
        min-height: calc(100vh - 200px);
    }
    
    .admin-sidebar {
        width: 250px;
        background: #2c3e50;
        color: white;
        padding: 20px 0;
    }
    
    .admin-content {
        flex: 1;
        padding: 30px;
        background: #f5f7fa;
    }
    
    .admin-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .admin-menu li {
        margin: 5px 0;
    }
    
    .admin-menu a {
        display: block;
        padding: 15px 25px;
        color: #ecf0f1;
        text-decoration: none;
        transition: all 0.3s;
        border-left: 4px solid transparent;
    }
    
    .admin-menu a:hover,
    .admin-menu a.active {
        background: #34495e;
        border-left-color: #3498db;
    }
    
    .admin-menu i {
        width: 25px;
        text-align: center;
        margin-right: 10px;
    }
    
    .admin-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        text-align: center;
    }
    
    .stat-card i {
        font-size: 2.5rem;
        color: #3498db;
        margin-bottom: 15px;
    }
    
    .stat-card h3 {
        font-size: 2.5rem;
        margin: 10px 0;
        color: #2c3e50;
    }
    
    .stat-card p {
        color: #7f8c8d;
        margin: 0;
    }
    
    .table-responsive {
        overflow-x: auto;
        background: white;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .admin-table th,
    .admin-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #eee;
    }
    
    .admin-table th {
        background: #f8f9fa;
        font-weight: 600;
        color: #2c3e50;
    }
    
    .admin-table tr:hover {
        background: #f8f9fa;
    }
    
    .btn-admin {
        padding: 8px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.9rem;
        transition: all 0.3s;
    }
    
    .btn-edit {
        background: #3498db;
        color: white;
    }
    
    .btn-delete {
        background: #e74c3c;
        color: white;
    }
    
    .btn-status {
        background: #2ecc71;
        color: white;
    }
    
    .status-badge {
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    .status-pending { background: #f39c12; color: white; }
    .status-processing { background: #3498db; color: white; }
    .status-delivering { background: #2ecc71; color: white; }
    .status-delivered { background: #7f8c8d; color: white; }
    .status-cancelled { background: #e74c3c; color: white; }
    </style>
</head>
<body>
    
    <div class="admin-container">
        <div class="admin-sidebar">
            <div style="padding: 0 25px 20px;">
                <h3><i class="fas fa-user-shield"></i> Админ-панель</h3>
                <p style="color: #bdc3c7; font-size: 0.9rem;"><?php echo htmlspecialchars($user['name']); ?></p>
            </div>
            
            <ul class="admin-menu">
                <li><a href="?action=dashboard" class="<?php echo ($action ?? '') === 'dashboard' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a></li>
                <li><a href="?action=orders" class="<?php echo ($action ?? '') === 'orders' ? 'active' : ''; ?>">
                    <i class="fas fa-shopping-cart"></i> Заказы
                </a></li>
                <li><a href="?action=restaurants" class="<?php echo ($action ?? '') === 'restaurants' ? 'active' : ''; ?>">
                    <i class="fas fa-utensils"></i> Рестораны
                </a></li>
                <li><a href="?action=dishes" class="<?php echo ($action ?? '') === 'dishes' ? 'active' : ''; ?>">
                    <i class="fas fa-hamburger"></i> Блюда
                </a></li>
                <li><a href="?action=users" class="<?php echo ($action ?? '') === 'users' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i> Пользователи
                </a></li>
                <li><a href="?action=reviews" class="<?php echo ($action ?? '') === 'reviews' ? 'active' : ''; ?>">
                    <i class="fas fa-star"></i> Отзывы
                </a></li>
                <li><a href="/account.php">
                    <i class="fas fa-arrow-left"></i> На сайт
                </a></li>
            </ul>
        </div>
        
        <div class="admin-content">