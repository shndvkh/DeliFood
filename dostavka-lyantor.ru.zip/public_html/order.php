<?php
require_once __DIR__ . '/includes/config.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

$user = getUser();
$cartItems = getCartItems();

if (empty($cartItems)) {
    redirect(BASE_URL . '/cart.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = sanitize($_POST['address']);
    $paymentMethod = sanitize($_POST['payment_method']);
    $comment = sanitize($_POST['comment'] ?? '');
    
    if (empty($address)) {
        $error = 'Укажите адрес доставки';
    } else {
        $db = getDB();
        
        try {
            $db->beginTransaction();
            
            $restaurantId = $cartItems[0]['dish']['restaurant_id'];
            $total = getCartTotal() + 200; // + доставка
            
            // Создаем заказ
            $stmt = $db->prepare("
                INSERT INTO orders (user_id, restaurant_id, total_amount, delivery_address, 
                                  payment_method, status, comment, created_at)
                VALUES (?, ?, ?, ?, ?, 'processing', ?, NOW())
            ");
            
            $stmt->execute([
                $user['id'],
                $restaurantId,
                $total,
                $address,
                $paymentMethod,
                $comment
            ]);
            
            $orderId = $db->lastInsertId();
            
            // Добавляем товары заказа
            $stmt = $db->prepare("
                INSERT INTO order_items (order_id, dish_id, quantity, price)
                VALUES (?, ?, ?, ?)
            ");
            
            foreach ($cartItems as $item) {
                $stmt->execute([
                    $orderId,
                    $item['dish']['id'],
                    $item['quantity'],
                    $item['dish']['price']
                ]);
            }
            
            $db->commit();
            
            clearCart();
            
            $_SESSION['order_success'] = true;
            $_SESSION['order_id'] = $orderId;
            
            redirect(BASE_URL . '/order-success.php?id=' . $orderId);
            
        } catch (Exception $e) {
            $db->rollBack();
            $error = 'Ошибка при оформлении заказа: ' . $e->getMessage();
        }
    }
}

$pageTitle = 'Оформление заказа';
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>Оформление заказа</h1>
        <p>Проверьте ваш заказ и укажите данные для доставки</p>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="order-process">
            <div class="order-steps">
                <div class="step active">
                    <div class="step-number">1</div>
                    <div class="step-title">Корзина</div>
                </div>
                <div class="step active">
                    <div class="step-number">2</div>
                    <div class="step-title">Оформление</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-title">Подтверждение</div>
                </div>
            </div>
            
            <div class="order-grid">
                <div class="order-items-section">
                    <h2>Ваш заказ</h2>
                    <div class="order-items-list">
                        <?php 
                        $restaurantName = '';
                        foreach ($cartItems as $item): 
                            $dish = $item['dish'];
                            $quantity = $item['quantity'];
                            $restaurantName = $dish['restaurant_name'];
                        ?>
                        <div class="order-item" data-id="<?php echo $dish['id']; ?>">
                            <div class="item-image">
                                <img src="<?php echo BASE_URL; ?>/assets/img/dishes/<?php echo $dish['image'] ?: 'default.jpg'; ?>" 
                                     alt="<?php echo htmlspecialchars($dish['name']); ?>">
                            </div>
                            <div class="item-info">
                                <h3><?php echo htmlspecialchars($dish['name']); ?></h3>
                                <p class="restaurant"><?php echo htmlspecialchars($dish['restaurant_name']); ?></p>
                                <p class="description"><?php echo htmlspecialchars($dish['description']); ?></p>
                            </div>
                            <div class="item-controls">
                                <div class="quantity-control">
                                    <button class="quantity-btn minus" data-id="<?php echo $dish['id']; ?>">-</button>
                                    <span class="quantity"><?php echo $quantity; ?></span>
                                    <button class="quantity-btn plus" data-id="<?php echo $dish['id']; ?>">+</button>
                                </div>
                                <div class="item-price">
                                    <span class="price"><?php echo formatPrice($dish['price'] * $quantity); ?></span>
                                    <button class="btn btn-sm btn-danger remove-item" data-id="<?php echo $dish['id']; ?>">
                                        <i class="fas fa-trash"></i> Удалить
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (!empty($restaurantName)): ?>
                    <div class="restaurant-info">
                        <h3>Ресторан: <?php echo htmlspecialchars($restaurantName); ?></h3>
                        <p>Доставка: 200 ₽ • Время: 30-40 мин</p>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="order-form-section">
                    <h2>Данные для доставки</h2>
                    <form method="POST" action="" class="order-form">
                        <div class="form-group">
                            <label for="name">Имя</label>
                            <input type="text" id="name" class="form-control" 
                                   value="<?php echo htmlspecialchars($user['name']); ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Телефон</label>
                            <input type="tel" id="phone" class="form-control" 
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Адрес доставки *</label>
                            <input type="text" id="address" name="address" class="form-control" required 
                                   value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>" 
                                   placeholder="Улица, дом, квартира, подъезд, этаж">
                        </div>
                        
                        <div class="form-group">
                            <label>Способ оплаты *</label>
                            <div class="payment-options">
                                <label class="payment-option">
                                    <input type="radio" name="payment_method" value="cash" checked>
                                    <div class="payment-content">
                                        <i class="fas fa-money-bill-wave"></i>
                                        <span>Наличными при получении</span>
                                    </div>
                                </label>
                                <label class="payment-option">
                                    <input type="radio" name="payment_method" value="card">
                                    <div class="payment-content">
                                        <i class="fas fa-credit-card"></i>
                                        <span>Картой онлайн</span>
                                    </div>
                                </label>
                                <label class="payment-option">
                                    <input type="radio" name="payment_method" value="card_courier">
                                    <div class="payment-content">
                                        <i class="fas fa-mobile-alt"></i>
                                        <span>Картой курьеру</span>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="comment">Комментарий к заказу</label>
                            <textarea id="comment" name="comment" class="form-control" rows="3" 
                                      placeholder="Особые пожелания, номер домофона, код от подъезда и т.д."></textarea>
                        </div>
                        
                        <div class="order-summary">
                            <div class="summary-row">
                                <span>Сумма заказа:</span>
                                <span id="orderSubtotal"><?php echo formatPrice(getCartTotal()); ?></span>
                            </div>
                            <div class="summary-row">
                                <span>Доставка:</span>
                                <span>200 ₽</span>
                            </div>
                            <div class="summary-row total">
                                <span>Итого к оплате:</span>
                                <span id="orderTotal"><?php echo formatPrice(getCartTotal() + 200); ?></span>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-block btn-lg">Подтвердить заказ</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.quantity-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const dishId = this.dataset.id;
        const isMinus = this.classList.contains('minus');
        
        fetch('api/cart.php?action=update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                dish_id: dishId,
                change: isMinus ? -1 : 1
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка при обновлении количества');
        });
    });
});

document.querySelectorAll('.remove-item').forEach(btn => {
    btn.addEventListener('click', function() {
        if (!confirm('Удалить товар из корзины?')) {
            return;
        }
        
        const dishId = this.dataset.id;
        
        fetch('api/cart.php?action=remove', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ dish_id: dishId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка при удалении товара');
        });
    });
});
</script>

<style>
.order-process {
    margin-top: 30px;
}

.order-steps {
    display: flex;
    justify-content: center;
    gap: 40px;
    margin-bottom: 40px;
}

.step {
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.step-number {
    width: 40px;
    height: 40px;
    background: #ddd;
    color: #666;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-bottom: 10px;
}

.step.active .step-number {
    background: #FF5722;
    color: white;
}

.step-title {
    font-size: 0.9rem;
    color: #666;
}

.step.active .step-title {
    color: #333;
    font-weight: 600;
}

.order-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
}

.order-items-list {
    background: white;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

.order-item {
    display: grid;
    grid-template-columns: 80px 1fr auto;
    gap: 20px;
    padding: 15px 0;
    border-bottom: 1px solid #eee;
    align-items: center;
}

.order-item:last-child {
    border-bottom: none;
}

.item-image img {
    width: 80px;
    height: 80px;
    border-radius: 8px;
    object-fit: cover;
}

.item-info h3 {
    margin: 0 0 5px 0;
    font-size: 1.1rem;
}

.restaurant {
    color: #666;
    font-size: 0.9rem;
    margin-bottom: 5px;
}

.description {
    color: #888;
    font-size: 0.9rem;
    margin: 0;
}

.item-controls {
    text-align: right;
}

.quantity-control {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
    margin-bottom: 10px;
}

.quantity-btn {
    width: 30px;
    height: 30px;
    border: 1px solid #ddd;
    background: white;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.quantity-btn:hover {
    background: #f5f5f5;
}

.quantity {
    min-width: 30px;
    text-align: center;
}

.item-price {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
}

.price {
    font-size: 1.2rem;
    font-weight: bold;
    color: #FF5722;
}

.restaurant-info {
    background: #f9f9f9;
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.payment-options {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 10px;
}

.payment-option {
    border: 2px solid #eee;
    border-radius: 8px;
    padding: 15px;
    cursor: pointer;
    transition: all 0.3s;
}

.payment-option:hover {
    border-color: #ddd;
}

.payment-option input[type="radio"]:checked + .payment-content {
    color: #FF5722;
}

.payment-option input[type="radio"]:checked {
    border-color: #FF5722;
}

.payment-content {
    display: flex;
    align-items: center;
    gap: 10px;
}

.payment-content i {
    font-size: 1.2rem;
}

.order-summary {
    background: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    margin: 20px 0;
}

.summary-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.summary-row.total {
    font-size: 1.3rem;
    font-weight: bold;
    color: #FF5722;
    border-bottom: none;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 2px solid #eee;
}

.btn-lg {
    padding: 15px;
    font-size: 1.1rem;
}

@media (max-width: 768px) {
    .order-grid {
        grid-template-columns: 1fr;
    }
    
    .order-steps {
        gap: 20px;
    }
    
    .order-item {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .item-controls {
        text-align: center;
    }
    
    .quantity-control {
        justify-content: center;
    }
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>