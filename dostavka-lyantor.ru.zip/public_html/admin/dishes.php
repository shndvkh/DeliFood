<?php
$db = getDB();

// ФИЛЬТР ПО РЕСТОРАНУ
$restaurantId = isset($_GET['restaurant_id']) ? intval($_GET['restaurant_id']) : 0;
$restaurant = null;

if ($restaurantId) {
    $stmt = $db->prepare("SELECT name FROM restaurants WHERE id = ?");
    $stmt->execute([$restaurantId]);
    $restaurant = $stmt->fetch();
}

// ФЛАГИ ДЛЯ ОТОБРАЖЕНИЯ СООБЩЕНИЙ
$message = '';
$messageType = '';

// ОБРАБОТКА УДАЛЕНИЯ БЛЮДА
if (isset($_GET['delete'])) {
    $dishId = intval($_GET['delete']);
    
    $stmt = $db->prepare("DELETE FROM dishes WHERE id = ?");
    if ($stmt->execute([$dishId])) {
        $message = 'Блюдо успешно удалено';
        $messageType = 'success';
    } else {
        $message = 'Ошибка при удалении блюда';
        $messageType = 'error';
    }
}

// ОБРАБОТКА СОХРАНЕНИЯ БЛЮДА
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_dish'])) {
    // Получаем данные из формы, только обрезаем пробелы
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price']);
    $restaurantIdPost = intval($_POST['restaurant_id']);
    $categoryId = isset($_POST['category_id']) ? intval($_POST['category_id']) : null;
    $image = trim($_POST['image'] ?? ''); // Новое поле для изображения
    $active = isset($_POST['active']) ? 1 : 0;
    $dishId = isset($_POST['dish_id']) ? intval($_POST['dish_id']) : 0;
    
    if ($dishId) {
        // Обновление
        $stmt = $db->prepare("
            UPDATE dishes 
            SET name = ?, description = ?, price = ?, restaurant_id = ?, 
                category_id = ?, image = ?, active = ?
            WHERE id = ?
        ");
        if ($stmt->execute([$name, $description, $price, $restaurantIdPost, $categoryId, $image, $active, $dishId])) {
            $message = 'Изменения сохранены';
            $messageType = 'success';
        }
    } else {
        // Создание нового
        $stmt = $db->prepare("
            INSERT INTO dishes (name, description, price, restaurant_id, category_id, image, active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        if ($stmt->execute([$name, $description, $price, $restaurantIdPost, $categoryId, $image, $active])) {
            $message = 'Блюдо успешно добавлено';
            $messageType = 'success';
            $dishId = $db->lastInsertId();
        }
    }
}

// ПРОСМОТР/РЕДАКТИРОВАНИЕ КОНКРЕТНОГО БЛЮДА
if (isset($_GET['edit']) || (isset($_POST['dish_id']) && $_POST['dish_id'])) {
    $dishId = isset($_GET['edit']) ? intval($_GET['edit']) : (isset($_POST['dish_id']) ? intval($_POST['dish_id']) : 0);
    $dish = null;
    
    if ($dishId) {
        $stmt = $db->prepare("SELECT * FROM dishes WHERE id = ?");
        $stmt->execute([$dishId]);
        $dish = $stmt->fetch();
    }
    
    // Получаем список ресторанов для выбора
    $stmt = $db->query("SELECT id, name FROM restaurants WHERE active = TRUE ORDER BY name");
    $restaurants = $stmt->fetchAll();
    
    // Получаем список категорий
    $stmt = $db->query("SELECT id, name FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
    ?>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h1><?php echo $dish ? 'Редактирование блюда' : 'Новое блюдо'; ?></h1>
        <a href="?action=dishes<?php echo $restaurantId ? '&restaurant_id=' . $restaurantId : ''; ?>" 
           class="btn btn-outline">
            ← Назад к списку
        </a>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 20px;">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="" style="max-width: 600px;">
        <input type="hidden" name="save_dish" value="1">
        <input type="hidden" name="dish_id" value="<?php echo $dishId; ?>">
        
        <div class="form-group">
            <label for="name">Название блюда *</label>
            <input type="text" id="name" name="name" class="form-control" 
                   value="<?php echo htmlspecialchars($dish['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="description">Описание</label>
            <textarea id="description" name="description" class="form-control" rows="3"><?php 
                echo htmlspecialchars($dish['description'] ?? '', ENT_QUOTES, 'UTF-8'); 
            ?></textarea>
        </div>
        
        <div class="form-group">
            <label for="price">Цена (₽) *</label>
            <input type="number" id="price" name="price" class="form-control" step="0.01" min="0"
                   value="<?php echo htmlspecialchars($dish['price'] ?? ''); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="image">Название файла изображения</label>
            <input type="text" id="image" name="image" class="form-control" 
                   value="<?php echo htmlspecialchars($dish['image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                   placeholder="Например: coffee.jpg">
            <small class="form-text">Имя файла из папки assets/img/dishes/. Оставьте пустым, чтобы использовать изображение по умолчанию.</small>
        </div>
        
        <div class="form-group">
            <label for="restaurant_id">Ресторан *</label>
            <select id="restaurant_id" name="restaurant_id" class="form-control" required>
                <option value="">-- Выберите ресторан --</option>
                <?php foreach ($restaurants as $r): ?>
                <option value="<?php echo htmlspecialchars($r['id']); ?>"
                    <?php echo (($dish && $dish['restaurant_id'] == $r['id']) || (!$dish && $restaurantId == $r['id'])) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8'); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="category_id">Категория</label>
            <select id="category_id" name="category_id" class="form-control">
                <option value="">-- Без категории --</option>
                <?php foreach ($categories as $cat): ?>
                <option value="<?php echo htmlspecialchars($cat['id']); ?>"
                    <?php echo ($dish && $dish['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat['name'], ENT_QUOTES, 'UTF-8'); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label class="checkbox">
                <input type="checkbox" name="active" value="1" 
                       <?php echo ($dish && $dish['active']) || !$dish ? 'checked' : ''; ?>>
                <span>Активно</span>
            </label>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Сохранить</button>
            <?php if ($dish): ?>
                <button type="button" 
                        onclick="if(confirm('Удалить блюдо?')) window.location.href='?action=dishes&delete=<?php echo htmlspecialchars($dish['id']); ?><?php echo $restaurantId ? '&restaurant_id=' . $restaurantId : ''; ?>'"
                        class="btn btn-danger">
                    Удалить
                </button>
            <?php endif; ?>
        </div>
    </form>
    
    <?php
    return;
}

// СПИСОК БЛЮД
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Формируем запрос с фильтрами
$where = [];
$params = [];

if ($restaurantId) {
    $where[] = "d.restaurant_id = ?";
    $params[] = $restaurantId;
}

$whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";

// Получаем блюда
$sql = "
    SELECT d.*, r.name as restaurant_name, c.name as category_name 
    FROM dishes d 
    LEFT JOIN restaurants r ON d.restaurant_id = r.id 
    LEFT JOIN categories c ON d.category_id = c.id 
    $whereClause
    ORDER BY d.id DESC 
    LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

$stmt = $db->prepare($sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$dishes = $stmt->fetchAll();

// Общее количество
$countSql = "SELECT COUNT(*) as total FROM dishes d $whereClause";
$countStmt = $db->prepare($countSql);
if (!empty($params)) {
    $countStmt->execute($params);
} else {
    $countStmt->execute();
}
$totalDishes = $countStmt->fetch()['total'];
$totalPages = ceil($totalDishes / $limit);
?>

<h1>Управление блюдами</h1>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 20px;">
        <?php echo htmlspecialchars($message); ?>
    </div>
<?php endif; ?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <a href="?action=dishes&edit=0" class="btn btn-primary">
            <i class="fas fa-plus"></i> Добавить блюдо
        </a>
        
        <?php if ($restaurant): ?>
            <span style="margin-left: 20px;">
                Ресторан: <strong><?php echo htmlspecialchars($restaurant['name'], ENT_QUOTES, 'UTF-8'); ?></strong>
            </span>
        <?php endif; ?>
    </div>
    
    <div>
        Всего блюд: <strong><?php echo htmlspecialchars($totalDishes); ?></strong>
    </div>
</div>

<?php if ($restaurantId): ?>
    <div style="margin-bottom: 20px;">
        <a href="?action=dishes" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Все блюда
        </a>
    </div>
<?php endif; ?>

<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Название</th>
                <th>Изображение</th>
                <th>Ресторан</th>
                <th>Категория</th>
                <th>Цена</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dishes as $dish): ?>
            <tr>
                <td><?php echo htmlspecialchars($dish['id']); ?></td>
                <td>
                    <strong><?php echo htmlspecialchars($dish['name'], ENT_QUOTES, 'UTF-8'); ?></strong>
                    <?php if ($dish['description']): ?>
                        <p style="margin: 5px 0 0 0; color: #666; font-size: 0.9rem;">
                            <?php 
                            $description = htmlspecialchars($dish['description'], ENT_QUOTES, 'UTF-8');
                            echo mb_strlen($description) > 50 
                                ? mb_substr($description, 0, 50) . '...' 
                                : $description; 
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($dish['image']): ?>
                        <span style="font-size: 0.9rem; color: #666;">
                            <?php echo htmlspecialchars($dish['image'], ENT_QUOTES, 'UTF-8'); ?>
                        </span>
                    <?php else: ?>
                        <span style="color: #999; font-size: 0.9rem;">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="?action=dishes&restaurant_id=<?php echo htmlspecialchars($dish['restaurant_id']); ?>">
                        <?php echo htmlspecialchars($dish['restaurant_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?>
                    </a>
                </td>
                <td><?php echo htmlspecialchars($dish['category_name'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo formatPrice($dish['price']); ?></td>
                <td>
                    <span class="status-badge <?php echo $dish['active'] ? 'status-delivered' : 'status-cancelled'; ?>">
                        <?php echo $dish['active'] ? 'Активно' : 'Неактивно'; ?>
                    </span>
                </td>
                <td>
                    <a href="?action=dishes&edit=<?php echo htmlspecialchars($dish['id']); ?>" 
                       class="btn-admin btn-edit" title="Редактировать">
                        <i class="fas fa-edit"></i>
                    </a>
                    <button onclick="if(confirm('Удалить блюдо?')) window.location.href='?action=dishes&delete=<?php echo htmlspecialchars($dish['id']); ?><?php echo $restaurantId ? "&restaurant_id=$restaurantId" : ""; ?>'" 
                       class="btn-admin btn-delete" title="Удалить">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination" style="display: flex; justify-content: center; margin-top: 20px; gap: 10px;">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?action=dishes&page=<?php echo htmlspecialchars($i); ?><?php echo $restaurantId ? "&restaurant_id=$restaurantId" : ''; ?>" 
           class="btn btn-outline <?php echo $i == $page ? 'active' : ''; ?>">
            <?php echo htmlspecialchars($i); ?>
        </a>
    <?php endfor; ?>
</div>
<?php endif; ?>