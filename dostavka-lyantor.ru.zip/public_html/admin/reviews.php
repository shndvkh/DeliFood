<?php
$db = getDB();

$message = '';
$messageType = '';

// УДАЛЕНИЕ ОТЗЫВА
if (isset($_GET['delete'])) {
    $reviewId = intval($_GET['delete']);
    
    // Получаем ресторан, чтобы обновить рейтинг
    $stmt = $db->prepare("SELECT restaurant_id FROM reviews WHERE id = ?");
    $stmt->execute([$reviewId]);
    $review = $stmt->fetch();
    
    // Удаляем отзыв
    $stmt = $db->prepare("DELETE FROM reviews WHERE id = ?");
    if ($stmt->execute([$reviewId])) {
        // Обновляем рейтинг ресторана
        if ($review && $review['restaurant_id']) {
            $stmt = $db->prepare("
                SELECT AVG(rating) as avg_rating 
                FROM reviews 
                WHERE restaurant_id = ? AND rating IS NOT NULL
            ");
            $stmt->execute([$review['restaurant_id']]);
            $result = $stmt->fetch();
            
            if ($result && $result['avg_rating']) {
                $updateStmt = $db->prepare("UPDATE restaurants SET rating = ? WHERE id = ?");
                $updateStmt->execute([round($result['avg_rating'], 1), $review['restaurant_id']]);
            } else {
                $updateStmt = $db->prepare("UPDATE restaurants SET rating = 0 WHERE id = ?");
                $updateStmt->execute([$review['restaurant_id']]);
            }
        }
        
        $message = 'Отзыв успешно удален';
        $messageType = 'success';
    } else {
        $message = 'Ошибка при удалении отзыва';
        $messageType = 'error';
    }
}

// ФИЛЬТРЫ
$filterRating = isset($_GET['rating']) ? intval($_GET['rating']) : 0;
$filterRestaurant = isset($_GET['restaurant_id']) ? intval($_GET['restaurant_id']) : 0;

$where = [];
$params = [];

if ($filterRating > 0) {
    $where[] = "r.rating = ?";
    $params[] = $filterRating;
}

if ($filterRestaurant > 0) {
    $where[] = "r.restaurant_id = ?";
    $params[] = $filterRestaurant;
}

$whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";

// СПИСОК ОТЗЫВОВ
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Получаем отзывы
$sql = "
    SELECT r.*, 
           u.name as user_name,
           u.email as user_email,
           res.name as restaurant_name
    FROM reviews r
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN restaurants res ON r.restaurant_id = res.id
    $whereClause
    ORDER BY r.created_at DESC 
    LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

$stmt = $db->prepare($sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$reviews = $stmt->fetchAll();

// Общее количество
$countSql = "SELECT COUNT(*) as total FROM reviews r $whereClause";
$countStmt = $db->prepare($countSql);
if (!empty($params)) {
    $countStmt->execute($params);
} else {
    $countStmt->execute();
}
$totalReviews = $countStmt->fetch()['total'];
$totalPages = ceil($totalReviews / $limit);

// Получаем список ресторанов для фильтра
$stmt = $db->query("SELECT id, name FROM restaurants WHERE active = TRUE ORDER BY name");
$restaurants = $stmt->fetchAll();

// Статистика
$stmt = $db->query("
    SELECT 
        COUNT(*) as total,
        AVG(rating) as avg_rating,
        SUM(CASE WHEN rating >= 4 THEN 1 ELSE 0 END) as positive_reviews
    FROM reviews
");
$stats = $stmt->fetch();
?>

<h1>Управление отзывами</h1>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>"><?php echo $message; ?></div>
<?php endif; ?>

<div class="reviews-stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
    <div class="stat-card">
        <div class="stats-icon">
            <i class="fas fa-star"></i>
        </div>
        <div class="stats-info">
            <h3><?php echo number_format($stats['avg_rating'] ?? 0, 1); ?></h3>
            <p>Средний рейтинг</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stats-icon">
            <i class="fas fa-comments"></i>
        </div>
        <div class="stats-info">
            <h3><?php echo $stats['total'] ?? 0; ?></h3>
            <p>Всего отзывов</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stats-icon">
            <i class="fas fa-thumbs-up"></i>
        </div>
        <div class="stats-info">
            <h3><?php echo $stats['positive_reviews'] ?? 0; ?></h3>
            <p>Положительных (4-5★)</p>
        </div>
    </div>
</div>

<div class="filters" style="background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
    <form method="GET" action="">
        <input type="hidden" name="action" value="reviews">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <div>
                <label>Фильтр по рейтингу:</label>
                <select name="rating" class="form-control">
                    <option value="0">Все рейтинги</option>
                    <option value="5" <?php echo $filterRating == 5 ? 'selected' : ''; ?>>5 звёзд</option>
                    <option value="4" <?php echo $filterRating == 4 ? 'selected' : ''; ?>>4 звезды</option>
                    <option value="3" <?php echo $filterRating == 3 ? 'selected' : ''; ?>>3 звезды</option>
                    <option value="2" <?php echo $filterRating == 2 ? 'selected' : ''; ?>>2 звезды</option>
                    <option value="1" <?php echo $filterRating == 1 ? 'selected' : ''; ?>>1 звезда</option>
                </select>
            </div>
            <div>
                <label>Фильтр по ресторану:</label>
                <select name="restaurant_id" class="form-control">
                    <option value="0">Все рестораны</option>
                    <?php foreach ($restaurants as $restaurant): ?>
                        <option value="<?php echo $restaurant['id']; ?>" 
                            <?php echo $filterRestaurant == $restaurant['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($restaurant['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="display: flex; align-items: flex-end;">
                <button type="submit" class="btn btn-primary">Фильтровать</button>
                <a href="?action=reviews" class="btn btn-outline" style="margin-left: 10px;">Сбросить</a>
            </div>
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Пользователь</th>
                <th>Ресторан</th>
                <th>Рейтинг</th>
                <th>Отзыв</th>
                <th>Дата</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reviews as $review): ?>
            <tr>
                <td><?php echo $review['id']; ?></td>
                <td>
                    <strong><?php echo htmlspecialchars($review['user_name']); ?></strong>
                    <p style="margin: 5px 0 0 0; color: #666; font-size: 0.9rem;">
                        <?php echo htmlspecialchars($review['user_email']); ?>
                    </p>
                </td>
                <td>
                    <?php if ($review['restaurant_name']): ?>
                        <a href="?action=restaurants&edit=<?php echo $review['restaurant_id']; ?>">
                            <?php echo htmlspecialchars($review['restaurant_name']); ?>
                        </a>
                    <?php else: ?>
                        <span style="color: #666;">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div style="display: flex; align-items: center; gap: 5px;">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star" style="color: <?php echo $i <= $review['rating'] ? '#FFC107' : '#ddd'; ?>;"></i>
                        <?php endfor; ?>
                        <span style="margin-left: 5px; font-weight: bold;"><?php echo $review['rating']; ?></span>
                    </div>
                </td>
                <td>
                    <?php if ($review['comment']): ?>
                        <span title="<?php echo htmlspecialchars($review['comment']); ?>">
                            <?php echo mb_strlen($review['comment']) > 50 
                                ? mb_substr($review['comment'], 0, 50) . '...' 
                                : htmlspecialchars($review['comment']); ?>
                        </span>
                    <?php else: ?>
                        <span style="color: #666;">—</span>
                    <?php endif; ?>
                </td>
                <td><?php echo date('d.m.Y', strtotime($review['created_at'])); ?></td>
                <td>
                    <button onclick="if(confirm('Удалить этот отзыв?')) window.location.href='?action=reviews&delete=<?php echo $review['id']; ?>'" 
                       class="btn-admin btn-delete" title="Удалить">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination" style="display: flex; justify-content: center; margin-top: 20px; gap: 10px;">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?action=reviews&page=<?php echo $i; ?><?php echo $filterRating ? "&rating=$filterRating" : ''; ?><?php echo $filterRestaurant ? "&restaurant_id=$filterRestaurant" : ''; ?>" 
           class="btn btn-outline <?php echo $i == $page ? 'active' : ''; ?>">
            <?php echo $i; ?>
        </a>
    <?php endfor; ?>
</div>
<?php endif; ?>