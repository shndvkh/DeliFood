    </main>
    
    <footer class="site-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><i class="fas fa-utensils"></i> <?php echo SITE_NAME; ?></h3>
                    <p>Доставка вкусной еды из лучших ресторанов города. Быстро, качественно, надёжно.</p>
                </div>
                
                <div class="footer-section">
                    <h3>Навигация</h3>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>/">Главная</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/#restaurants">Рестораны</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/#dishes">Блюда</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/order.php">Оформить заказ</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Аккаунт</h3>
                    <ul>
                        <?php if ($user): ?>
                            <li><a href="<?php echo BASE_URL; ?>/account.php">Личный кабинет</a></li>
                            <li><a href="<?php echo BASE_URL; ?>/logout.php">Выйти</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo BASE_URL; ?>/login.php">Войти</a></li>
                            <li><a href="<?php echo BASE_URL; ?>/register.php">Регистрация</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Контакты</h3>
                    <ul class="contact-info">
                        <li><i class="fas fa-phone"></i> +7 (952) 123-45-67</li>
                        <li><i class="fas fa-envelope"></i> info@dostavka-lyantor.ru</li>
                        <li><i class="fas fa-map-marker-alt"></i> г. Лянтор</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Все права защищены.</p>
            </div>
        </div>
    </footer>
    
    <script src="<?php echo ASSETS_URL; ?>/assets/js/script.js"></script>
    
</body>
</html>