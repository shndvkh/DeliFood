<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'add':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $dishId = $data['dish_id'] ?? 0;
            $quantity = $data['quantity'] ?? 1;
            
            if ($dishId > 0) {
                addToCart($dishId, $quantity);
                echo json_encode(['success' => true, 'count' => getCartCount()]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid dish ID']);
            }
        }
        break;
        
    case 'update':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $dishId = $data['dish_id'] ?? 0;
            $change = $data['change'] ?? 0;
            
            if ($dishId > 0) {
                $currentQuantity = $_SESSION['cart'][$dishId] ?? 0;
                $newQuantity = $currentQuantity + $change;
                
                if ($newQuantity <= 0) {
                    removeFromCart($dishId);
                } else {
                    updateCart($dishId, $newQuantity);
                }
                
                echo json_encode(['success' => true, 'count' => getCartCount()]);
            }
        }
        break;
        
    case 'remove':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $dishId = $data['dish_id'] ?? 0;
            
            if ($dishId > 0) {
                removeFromCart($dishId);
                echo json_encode(['success' => true, 'count' => getCartCount()]);
            }
        }
        break;
        
    case 'count':
        echo json_encode(['success' => true, 'count' => getCartCount()]);
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
?>