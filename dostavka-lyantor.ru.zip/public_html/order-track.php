<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/config.php';

if (!isLoggedIn()) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$orderId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$orderId) {
    $pageTitle = 'Отследить заказ';
    require_once __DIR__ . '/includes/header.php';
    ?>
    
    <div class="page-header">
        <div class="container">
            <h1>Отследить заказ</h1>
            <p>Введите номер вашего заказа для отслеживания</p>
        </div>
    </div>
    
    <div class="page-content">
        <div class="container">
            <div class="track-order-form" style="max-width: 500px; margin: 0 auto;">
                <form method="GET" action="">
                    <div class="form-group">
                        <label for="orderNumber">Номер заказа</label>
                        <input type="text" id="orderNumber" name="id" class="form-control" 
                               placeholder="Например: 12345" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Отследить</button>
                </form>
                
                <div class="help-info" style="margin-top: 30px; text-align: center;">
                    <p><i class="fas fa-question-circle"></i> Номер заказа вы можете найти:</p>
                    <ul style="text-align: left; margin-top: 10px;">
                        <li>В письме на email</li>
                        <li>В СМС уведомлении</li>
                        <li>В разделе "Мои заказы" в личном кабинете</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

try {
    $db = getDB();
    $user = getUser();
    
    if (!$user || !isset($user['id'])) {
        throw new Exception('Пользователь не найден');
    }

    $stmt = $db->prepare("
        SELECT o.*, 
               r.name as restaurant_name,
               r.delivery_time as restaurant_delivery_time
        FROM orders o
        LEFT JOIN restaurants r ON o.restaurant_id = r.id
        WHERE o.id = ? AND o.user_id = ?
    ");
    
    if (!$stmt) {
        throw new Exception('Ошибка подготовки запроса: ' . $db->errorInfo()[2]);
    }
    
    $result = $stmt->execute([$orderId, $user['id']]);
    
    if (!$result) {
        throw new Exception('Ошибка выполнения запроса: ' . implode(', ', $stmt->errorInfo()));
    }
    
    $order = $stmt->fetch();
    
    if (!$order) {
        $_SESSION['error_message'] = 'Заказ не найден или у вас нет доступа к этому заказу';
        header('Location: ' . BASE_URL . '/order-track.php');
        exit;
    }

    $stmt = $db->prepare("
        SELECT * FROM orders
        WHERE id = ? 
        ORDER BY created_at DESC
    ");
    
    $orderHistory = [];
    if ($stmt) {
        $stmt->execute([$orderId]);
        $orderHistory = $stmt->fetchAll() ?: [];
    }
    
} catch (Exception $e) {
    error_log('Order track error: ' . $e->getMessage());
    echo '<div class="container"><div class="alert alert-error">Произошла ошибка при загрузке информации о заказе</div></div>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = 'Отслеживание заказа #' . $orderId;
require_once __DIR__ . '/includes/header.php';
?>


<div class="page-header">
    <div class="container">
        <h1>Отслеживание заказа</h1>
        <p>Номер заказа: <strong>#<?php echo $orderId; ?></strong></p>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <div class="order-tracking">
            <!-- Трекер статусов -->
            <div class="tracker">
                <div class="tracker-step <?php echo in_array($order['status'], ['pending', 'processing', 'delivering', 'delivered']) ? 'completed' : ''; ?>">
                    <div class="step-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="step-info">
                        <h4>Заказ оформлен</h4>
                        <p><?php echo date('H:i', strtotime($order['created_at'])); ?></p>
                    </div>
                </div>
                
                <div class="tracker-step <?php echo in_array($order['status'], ['processing', 'delivering', 'delivered']) ? 'completed' : ''; ?>">
                    <div class="step-icon">
                        <i class="fas fa-utensils"></i>
                    </div>
                    <div class="step-info">
                        <h4>Готовится</h4>
                        <p>Ресторан готовит ваш заказ</p>
                    </div>
                </div>
                
                <div class="tracker-step <?php echo in_array($order['status'], ['delivering', 'delivered']) ? 'completed' : ''; ?>">
                    <div class="step-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="step-info">
                        <h4>В пути</h4>
                        <p>Курьер доставляет заказ</p>
                    </div>
                </div>
                
                <div class="tracker-step <?php echo $order['status'] === 'delivered' ? 'completed' : ''; ?>">
                    <div class="step-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="step-info">
                        <h4>Доставлен</h4>
                        <p>Заказ успешно доставлен</p>
                    </div>
                </div>
            </div>
            
            <!-- Информация о доставке -->
            <div class="delivery-info">
                <h3><i class="fas fa-info-circle"></i> Информация о доставке</h3>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Текущий статус:</span>
                        <span class="value status-badge status-<?php echo $order['status']; ?>">
                            <?php 
                            $statusTexts = [
                                'pending' => 'Ожидает подтверждения',
                                'processing' => 'Готовится',
                                'delivering' => 'В пути',
                                'delivered' => 'Доставлен',
                                'cancelled' => 'Отменен'
                            ];
                            echo $statusTexts[$order['status']];
                            ?>
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="label">Ресторан:</span>
                        <span class="value"><?php echo htmlspecialchars($order['restaurant_name']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="label">Адрес доставки:</span>
                        <span class="value"><?php echo htmlspecialchars($order['delivery_address']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="label">Ожидаемое время:</span>
                        <span class="value"><?php echo $order['restaurant_delivery_time']; ?></span>
                    </div>
                </div>
            </div>
            
            
            <!-- Действия -->
            <div class="tracking-actions">
                <a href="<?php echo BASE_URL; ?>/order-success.php?id=<?php echo $orderId; ?>" 
                   class="btn btn-primary">
                    <i class="fas fa-receipt"></i> Детали заказа
                </a>
                <a href="<?php echo BASE_URL; ?>/account.php" class="btn btn-outline">
                    <i class="fas fa-user"></i> Личный кабинет
                </a>
                <button class="btn btn-secondary" onclick="window.location.reload()">
                    <i class="fas fa-sync"></i> Обновить
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.order-tracking {
    max-width: 800px;
    margin: 0 auto;
}

.tracker {
    display: flex;
    justify-content: space-between;
    position: relative;
    margin-bottom: 40px;
}

.tracker:before {
    content: '';
    position: absolute;
    top: 30px;
    left: 0;
    right: 0;
    height: 3px;
    background: #ddd;
    z-index: 1;
}

.tracker-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    z-index: 2;
    text-align: center;
    flex: 1;
}

.tracker-step.completed .step-icon {
    background: #4CAF50;
}

.tracker-step.completed:before {
    background: #4CAF50;
}

.tracker-step:before {
    content: '';
    position: absolute;
    top: 30px;
    left: 50%;
    width: 0;
    height: 3px;
    background: #ddd;
    transition: width 0.3s;
}

.tracker-step.completed:before {
    width: 100%;
    left: -50%;
}

.step-icon {
    width: 60px;
    height: 60px;
    background: #ddd;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin-bottom: 15px;
    transition: all 0.3s;
}

.step-info h4 {
    margin: 0 0 5px 0;
    font-size: 1rem;
    color: #333;
}

.step-info p {
    margin: 0;
    color: #666;
    font-size: 0.9rem;
}

.delivery-info {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 30px;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #eee;
}

.info-item:last-child {
    border-bottom: none;
}

.label {
    color: #666;
    font-weight: 500;
}

.value {
    color: #333;
    text-align: right;
}

.status-badge {
    display: inline-block;
    padding: 5px 15px;
    border-radius: 20px;
    color: white;
    font-size: 0.9rem;
    font-weight: 600;
}

.status-pending { background-color: #FF9800; }
.status-processing { background-color: #2196F3; }
.status-delivering { background-color: #4CAF50; }
.status-delivered { background-color: #607D8B; }
.status-cancelled { background-color: #F44336; }

.order-history {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 30px;
}

.history-list {
    margin-top: 20px;
    position: relative;
    padding-left: 20px;
}

.history-list:before {
    content: '';
    position: absolute;
    left: 9px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #ddd;
}

.history-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 20px;
    position: relative;
}

.history-item:last-child {
    margin-bottom: 0;
}

.history-time {
    min-width: 80px;
    color: #666;
    font-weight: 500;
}

.history-dot {
    width: 20px;
    height: 20px;
    background: #FF5722;
    border-radius: 50%;
    margin: 0 15px;
    position: relative;
    z-index: 2;
    flex-shrink: 0;
}

.history-description {
    color: #333;
    flex: 1;
}

.tracking-actions {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}

@media (max-width: 768px) {
    .tracker {
        flex-direction: column;
        gap: 30px;
    }
    
    .tracker:before {
        display: none;
    }
    
    .tracker-step {
        flex-direction: row;
        text-align: left;
        gap: 20px;
    }
    
    .tracker-step:before {
        display: none;
    }
    
    .info-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 5px;
    }
    
    .value {
        text-align: left;
    }
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>