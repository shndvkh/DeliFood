<?php
$db = getDB();

$message = '';
$messageType = '';

// ПРОСМОТР/РЕДАКТИРОВАНИЕ ПОЛЬЗОВАТЕЛЯ
if (isset($_GET['edit'])) {
    $userId = intval($_GET['edit']);
    $user = null;
    
    if ($userId) {
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
    }
    
    // Сохранение изменений
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
        $name = sanitize($_POST['name']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone'] ?? '');
        $address = sanitize($_POST['address'] ?? '');
        
        if ($userId) {
            // Обновление
            $stmt = $db->prepare("
                UPDATE users 
                SET name = ?, email = ?, phone = ?, address = ?
                WHERE id = ?
            ");
            if ($stmt->execute([$name, $email, $phone, $address, $userId])) {
                $message = 'Изменения сохранены';
                $messageType = 'success';
                // Обновляем данные
                $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $user = $stmt->fetch();
            }
        }
    }
    ?>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h1><?php echo $user ? 'Редактирование пользователя' : 'Пользователь не найден'; ?></h1>
        <a href="?action=users" class="btn btn-outline">← Назад к списку</a>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 20px;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($user): ?>
    <form method="POST" action="" style="max-width: 600px;">
        <input type="hidden" name="save_user" value="1">
        
        <div class="form-group">
            <label for="name">Имя *</label>
            <input type="text" id="name" name="name" class="form-control" 
                   value="<?php echo htmlspecialchars($user['name']); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email" class="form-control" 
                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="phone">Телефон</label>
            <input type="tel" id="phone" name="phone" class="form-control" 
                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
        </div>
        
        <div class="form-group">
            <label for="address">Адрес</label>
            <textarea id="address" name="address" class="form-control" rows="3"><?php 
                echo htmlspecialchars($user['address'] ?? ''); 
            ?></textarea>
        </div>
        
        <div class="form-group">
            <p><strong>Дата регистрации:</strong> <?php echo date('d.m.Y H:i', strtotime($user['created_at'])); ?></p>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>
    
    <div style="margin-top: 40px;">
        <h3>Заказы пользователя</h3>
        <?php
        $stmt = $db->prepare("
            SELECT o.*, r.name as restaurant_name 
            FROM orders o 
            LEFT JOIN restaurants r ON o.restaurant_id = r.id 
            WHERE o.user_id = ? 
            ORDER BY o.created_at DESC 
            LIMIT 10
        ");
        $stmt->execute([$userId]);
        $userOrders = $stmt->fetchAll();
        
        if ($userOrders): ?>
            <div class="table-responsive" style="margin-top: 20px;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID заказа</th>
                            <th>Ресторан</th>
                            <th>Сумма</th>
                            <th>Статус</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($userOrders as $order): ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['restaurant_name']); ?></td>
                            <td><?php echo formatPrice($order['total_amount']); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php 
                                    $statuses = [
                                        'pending' => 'Ожидает',
                                        'processing' => 'В обработке',
                                        'delivering' => 'Доставляется',
                                        'delivered' => 'Доставлен',
                                        'cancelled' => 'Отменен'
                                    ];
                                    echo $statuses[$order['status']];
                                    ?>
                                </span>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="?action=orders&view=<?php echo $order['id']; ?>" class="btn-admin btn-edit">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>Пользователь еще не делал заказов</p>
        <?php endif; ?>
    </div>
    <?php endif;
    
    return;
}

// СПИСОК ПОЛЬЗОВАТЕЛЕЙ
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Поиск
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$where = [];
$params = [];

if ($search) {
    $where[] = "(name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";

// Получаем пользователей
$sql = "
    SELECT * FROM users 
    $whereClause
    ORDER BY created_at DESC 
    LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

$stmt = $db->prepare($sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$users = $stmt->fetchAll();

// Общее количество
$countSql = "SELECT COUNT(*) as total FROM users $whereClause";
$countStmt = $db->prepare($countSql);
if (!empty($params)) {
    $countStmt->execute($params);
} else {
    $countStmt->execute();
}
$totalUsers = $countStmt->fetch()['total'];
$totalPages = ceil($totalUsers / $limit);
?>

<h1>Управление пользователями</h1>

<div style="margin-bottom: 20px;">
    <form method="GET" action="" style="display: flex; gap: 10px; max-width: 500px;">
        <input type="hidden" name="action" value="users">
        <input type="text" name="search" class="form-control" placeholder="Поиск по имени, email или телефону..." 
               value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit" class="btn btn-primary">Найти</button>
        <?php if ($search): ?>
            <a href="?action=users" class="btn btn-outline">Сбросить</a>
        <?php endif; ?>
    </form>
</div>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        Всего пользователей: <strong><?php echo $totalUsers; ?></strong>
    </div>
</div>

<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Имя</th>
                <th>Email</th>
                <th>Телефон</th>
                <th>Адрес</th>
                <th>Дата регистрации</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td>
                    <strong><?php echo htmlspecialchars($user['name']); ?></strong>
                </td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo htmlspecialchars($user['phone'] ?? '—'); ?></td>
                <td>
                    <?php if ($user['address']): ?>
                        <span title="<?php echo htmlspecialchars($user['address']); ?>">
                            <?php echo mb_strlen($user['address']) > 30 
                                ? mb_substr($user['address'], 0, 30) . '...' 
                                : htmlspecialchars($user['address']); ?>
                        </span>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
                <td><?php echo date('d.m.Y', strtotime($user['created_at'])); ?></td>
                <td>
                    <a href="?action=users&edit=<?php echo $user['id']; ?>" 
                       class="btn-admin btn-edit" title="Редактировать">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="?action=orders<?php echo $user['id'] ? '&user_id=' . $user['id'] : ''; ?>" 
                       class="btn-admin btn-primary" title="Заказы">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination" style="display: flex; justify-content: center; margin-top: 20px; gap: 10px;">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?action=users&page=<?php echo $i; ?><?php echo $search ? "&search=" . urlencode($search) : ''; ?>" 
           class="btn btn-outline <?php echo $i == $page ? 'active' : ''; ?>">
            <?php echo $i; ?>
        </a>
    <?php endfor; ?>
</div>
<?php endif; ?>