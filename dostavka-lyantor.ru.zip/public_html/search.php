<?php
require_once __DIR__ . '/includes/config.php';

$pageTitle = 'Поиск ресторанов';
require_once __DIR__ . '/includes/header.php';

$address = isset($_GET['address']) ? sanitize($_GET['address']) : '';
$restaurants = [];

if ($address) {
    $db = getDB();
    
    $stmt = $db->query("SELECT * FROM restaurants WHERE active = TRUE ORDER BY rating DESC");
    $restaurants = $stmt->fetchAll();
}
?>

<div class="page-header">
    <div class="container">
        <h1>Поиск ресторанов</h1>
        <form method="GET" action="" class="search-form">
            <div class="search-box" style="max-width: 600px; margin: 20px auto;">
                <input type="text" name="address" class="search-input" 
                       value="<?php echo htmlspecialchars($address); ?>" 
                       placeholder="Введите адрес доставки..." required>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Найти
                </button>
            </div>
        </form>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <?php if ($address): ?>
            <?php if (empty($restaurants)): ?>
                <div class="text-center" style="padding: 60px 0;">
                    <i class="fas fa-search" style="font-size: 80px; color: #ddd; margin-bottom: 20px;"></i>
                    <h2>Рестораны не найдены</h2>
                    <p>К сожалению, по вашему адресу "<?php echo htmlspecialchars($address); ?>" нет доступных ресторанов.</p>
                    <p>Попробуйте другой адрес или проверьте правильность ввода.</p>
                    <a href="<?php echo BASE_URL; ?>/" class="btn btn-primary mt-1">На главную</a>
                </div>
            <?php else: ?>
                <div class="search-results">
                    <h2>Рестораны, доступные по адресу: "<?php echo htmlspecialchars($address); ?>"</h2>
                    <p class="results-count">Найдено <?php echo count($restaurants); ?> ресторанов</p>
                    
                    <div class="restaurants-grid">
                        <?php foreach ($restaurants as $restaurant): ?>
                        <div class="restaurant-card">
                            <div class="restaurant-info">
                                <h3><?php echo htmlspecialchars($restaurant['name']); ?></h3>
                                <p class="cuisine"><?php echo htmlspecialchars($restaurant['cuisine']); ?></p>
                                <p class="description"><?php echo htmlspecialchars($restaurant['description'] ?? ''); ?></p>
                                
                                <div class="restaurant-meta">
                                    <span class="rating">
                                        <i class="fas fa-star"></i> 
                                        <?php 
                                        $stmt = $db->prepare("
                                            SELECT COALESCE(AVG(rating), 0) as real_rating, 
                                                COUNT(*) as reviews_count 
                                            FROM reviews 
                                            WHERE restaurant_id = ?
                                        ");
                                        $stmt->execute([$restaurant['id']]);
                                        $ratingData = $stmt->fetch();
                                        
                                        echo number_format($ratingData['real_rating'], 1);
                                        ?>
                                    </span>
                                    <span class="delivery-time">
                                        <i class="fas fa-clock"></i> <?php echo $restaurant['delivery_time']; ?>
                                    </span>
                                    <span class="delivery-price">
                                        <i class="fas fa-truck"></i> 200 ₽
                                    </span>
                                </div>
                                
                                <div class="restaurant-actions">
                                    <a href="restaurant.php?id=<?php echo $restaurant['id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-utensils"></i> Смотреть меню
                                    </a>
                                    <!-- УДАЛИТЬ ЭТУ КНОПКУ:
                                    <button class="btn btn-outline add-to-favorites" 
                                            data-id="<?php echo $restaurant['id']; ?>">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                    -->
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="how-it-works" style="max-width: 800px; margin: 0 auto; text-align: center;">
                <h2>Как работает поиск ресторанов?</h2>
                <div class="steps" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; margin-top: 40px;">
                    <div class="step">
                        <div class="step-icon" style="background: #FF5722; color: white; width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 1.8rem;">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h3>Введите адрес</h3>
                        <p>Укажите точный адрес доставки</p>
                    </div>
                    <div class="step">
                        <div class="step-icon" style="background: #4CAF50; color: white; width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 1.8rem;">
                            <i class="fas fa-search"></i>
                        </div>
                        <h3>Найдите рестораны</h3>
                        <p>Система найдет доступные рестораны</p>
                    </div>
                    <div class="step">
                        <div class="step-icon" style="background: #2196F3; color: white; width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 1.8rem;">
                            <i class="fas fa-utensils"></i>
                        </div>
                        <h3>Выберите блюда</h3>
                        <p>Закажите из меню ресторана</p>
                    </div>
                    <div class="step">
                        <div class="step-icon" style="background: #FFC107; color: white; width: 70px; height: 70px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 1.8rem;">
                            <i class="fas fa-truck"></i>
                        </div>
                        <h3>Получите заказ</h3>
                        <p>Быстрая доставка до вашей двери</p>
                    </div>
                </div>
                
                <div style="margin-top: 50px;">
                    <h3>Популярные районы доставки в Лянторе</h3>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; margin-top: 20px;">
                        <a href="search.php?address=г. Лянтор, Центр" class="btn btn-outline">Центр</a>
                        <a href="search.php?address=г. Лянтор, 1-й микрорайон" class="btn btn-outline">1-й микрорайон</a>
                        <a href="search.php?address=г. Лянтор, 2-й микрорайон" class="btn btn-outline">2-й микрорайон</a>
                        <a href="search.php?address=г. Лянтор, 3-й микрорайон" class="btn btn-outline">3-й микрорайон</a>
                        <a href="search.php?address=г. Лянтор, ул. Ленина" class="btn btn-outline">ул. Ленина</a>
                        <a href="search.php?address=г. Лянтор, ул. Мира" class="btn btn-outline">ул. Мира</a>
                        <a href="search.php?address=г. Лянтор, ул. Советская" class="btn btn-outline">ул. Советская</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.querySelectorAll('.view-menu').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        const restaurantId = this.dataset.id;
        
        showNotification('Переход к меню ресторана #' + restaurantId + ' (в разработке)');
    });
});

</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>