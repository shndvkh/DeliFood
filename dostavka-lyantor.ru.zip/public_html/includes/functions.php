<?php
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUser() {
    if (isLoggedIn()) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    }
    return null;
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function formatPrice($price) {
    return number_format($price, 0, ',', ' ') . ' ' . CURRENCY;
}

function getCart() {
    return isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
}

function addToCart($dishId, $quantity = 1) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if (isset($_SESSION['cart'][$dishId])) {
        $_SESSION['cart'][$dishId] += $quantity;
    } else {
        $_SESSION['cart'][$dishId] = $quantity;
    }
}

function removeFromCart($dishId) {
    if (isset($_SESSION['cart'][$dishId])) {
        unset($_SESSION['cart'][$dishId]);
    }
}

function updateCart($dishId, $quantity) {
    if ($quantity <= 0) {
        removeFromCart($dishId);
    } else {
        $_SESSION['cart'][$dishId] = $quantity;
    }
}

function clearCart() {
    $_SESSION['cart'] = [];
}

function getCartCount() {
    if (!isset($_SESSION['cart'])) return 0;
    return array_sum($_SESSION['cart']);
}

function getCartTotal() {
    $total = 0;
    if (isset($_SESSION['cart'])) {
        $db = getDB();
        foreach ($_SESSION['cart'] as $dishId => $quantity) {
            $stmt = $db->prepare("SELECT price FROM dishes WHERE id = ?");
            $stmt->execute([$dishId]);
            $dish = $stmt->fetch();
            if ($dish) {
                $total += $dish['price'] * $quantity;
            }
        }
    }
    return $total;
}

function getCartItems() {
    $items = [];
    if (isset($_SESSION['cart'])) {
        $db = getDB();
        $dishIds = array_keys($_SESSION['cart']);
        if (!empty($dishIds)) {
            $placeholders = str_repeat('?,', count($dishIds) - 1) . '?';
            $stmt = $db->prepare("
                SELECT d.*, r.name as restaurant_name 
                FROM dishes d 
                LEFT JOIN restaurants r ON d.restaurant_id = r.id 
                WHERE d.id IN ($placeholders)
            ");
            $stmt->execute($dishIds);
            $dishes = $stmt->fetchAll();
            
            foreach ($dishes as $dish) {
                $items[] = [
                    'dish' => $dish,
                    'quantity' => $_SESSION['cart'][$dish['id']]
                ];
            }
        }
    }
    return $items;
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function getReviewsText($count) {
    if ($count == 0) return 'нет отзывов';
    
    $lastDigit = $count % 10;
    $lastTwoDigits = $count % 100;
    
    if ($lastTwoDigits >= 11 && $lastTwoDigits <= 19) {
        return $count . ' отзывов';
    }
    
    switch ($lastDigit) {
        case 1:
            return $count . ' отзыв';
        case 2:
        case 3:
        case 4:
            return $count . ' отзыва';
        default:
            return $count . ' отзывов';
    }
}

?>