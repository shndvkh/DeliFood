<?php
session_start();

$base_dir = dirname(dirname(__FILE__));
$base_url = 'https://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
$base_url = rtrim($base_url, '/');

if (strpos($base_url, '/admin') !== false) {
    $assets_base_url = str_replace('/admin', '', $base_url);
} else {
    $assets_base_url = $base_url;
}

define('BASE_DIR', $base_dir);
define('BASE_URL', $base_url);
define('ASSETS_URL', $assets_base_url);
define('SITE_NAME', 'Доставка.Еды');

define('CITY_NAME', 'Лянтор');
define('CITY_GENITIVE', 'Лянтора');
define('DEFAULT_ADDRESS', 'г. Лянтор');
define('CURRENCY', '₽');

require_once BASE_DIR . '/config/database.php';

spl_autoload_register(function($class) {
    $file = BASE_DIR . '/classes/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

require_once BASE_DIR . '/includes/functions.php';
require_once BASE_DIR . '/includes/database.php';