<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$db = getDB();

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $db->prepare("SELECT * FROM restaurants WHERE id = ? AND active = TRUE");
    $stmt->execute([$id]);
    $restaurant = $stmt->fetch();
    
    if ($restaurant) {
        // Получаем блюда ресторана
        $stmt = $db->prepare("SELECT * FROM dishes WHERE restaurant_id = ? AND active = TRUE");
        $stmt->execute([$id]);
        $restaurant['dishes'] = $stmt->fetchAll();
        
        echo json_encode($restaurant);
    } else {
        echo json_encode(['error' => 'Restaurant not found']);
    }
} else {
    $stmt = $db->query("SELECT * FROM restaurants WHERE active = TRUE ORDER BY rating DESC");
    $restaurants = $stmt->fetchAll();
    echo json_encode($restaurants);
}
?>