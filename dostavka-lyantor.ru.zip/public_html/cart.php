<?php
require_once __DIR__ . '/includes/config.php';

$pageTitle = 'Корзина';
require_once __DIR__ . '/includes/header.php';

$cartItems = getCartItems();
$cartTotal = getCartTotal();
?>

<div class="page-header">
    <div class="container">
        <h1>Корзина</h1>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <?php if (empty($cartItems)): ?>
            <div class="text-center" style="padding: 60px 0;">
                <i class="fas fa-shopping-cart" style="font-size: 80px; color: #ddd; margin-bottom: 20px;"></i>
                <h2>Ваша корзина пуста</h2>
                <p>Добавьте товары из меню ресторанов</p>
                <a href="<?php echo BASE_URL; ?>/" class="btn btn-primary mt-1">Перейти к меню</a>
            </div>
        <?php else: ?>
            <div class="cart-items">
                <?php foreach ($cartItems as $item): 
                    $dish = $item['dish'];
                    $quantity = $item['quantity'];
                ?>
                <div class="cart-item">
                    <div class="cart-item-image">
                        <img src="<?php echo ASSETS_URL; ?>/assets/img/dishes/<?php echo $dish['image'] ?: 'default.jpg'; ?>" alt="<?php echo htmlspecialchars($dish['name']); ?>">
                    </div>
                    <div class="cart-item-info">
                        <h3><?php echo htmlspecialchars($dish['name']); ?></h3>
                        <p><?php echo htmlspecialchars($dish['restaurant_name']); ?></p>
                        <div class="quantity-control">
                            <button class="quantity-btn minus" data-id="<?php echo $dish['id']; ?>">-</button>
                            <span class="quantity"><?php echo $quantity; ?></span>
                            <button class="quantity-btn plus" data-id="<?php echo $dish['id']; ?>">+</button>
                        </div>
                    </div>
                    <div class="cart-item-price">
                        <span class="price"><?php echo formatPrice($dish['price'] * $quantity); ?></span>
                        <button class="btn btn-outline btn-sm remove-item" data-id="<?php echo $dish['id']; ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="cart-summary">
                <div class="summary-row">
                    <span>Сумма заказа:</span>
                    <span><?php echo formatPrice($cartTotal); ?></span>
                </div>
                <div class="summary-row">
                    <span>Доставка:</span>
                    <span>200 ₽</span>
                </div>
                <div class="summary-row total-row">
                    <span>Итого:</span>
                    <span><?php echo formatPrice($cartTotal + 200); ?></span>
                </div>
                
                <div class="mt-2">
                    <?php if (isLoggedIn()): ?>
                        <a href="<?php echo BASE_URL; ?>/order.php" class="btn btn-primary btn-block">Оформить заказ</a>
                    <?php else: ?>
                        <div class="alert alert-error">
                            Для оформления заказа необходимо <a href="<?php echo BASE_URL; ?>/login.php">войти</a> в систему
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="text-center mt-2">
                    <a href="<?php echo BASE_URL; ?>/" class="btn btn-outline">Продолжить покупки</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.querySelectorAll('.quantity-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const dishId = this.dataset.id;
        const isMinus = this.classList.contains('minus');
        
        fetch('api/cart.php?action=update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                dish_id: dishId,
                change: isMinus ? -1 : 1
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        });
    });
});

document.querySelectorAll('.remove-item').forEach(btn => {
    btn.addEventListener('click', function() {
        const dishId = this.dataset.id;
        
        fetch('api/cart.php?action=remove', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ dish_id: dishId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        });
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>