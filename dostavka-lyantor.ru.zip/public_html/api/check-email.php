<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$email = isset($_GET['email']) ? sanitize($_GET['email']) : '';

if (empty($email)) {
    echo json_encode(['exists' => false]);
    exit;
}

// Валидация формата email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['exists' => false, 'invalid' => true]);
    exit;
}

$db = getDB();
$stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);

echo json_encode([
    'exists' => $stmt->rowCount() > 0,
    'email' => $email
]);
?>