<?php
require_once __DIR__ . '/includes/config.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

$user = getUser();
$db = getDB();

// Получаем заказы пользователя
$stmt = $db->prepare("
    SELECT o.*, r.name as restaurant_name 
    FROM orders o 
    LEFT JOIN restaurants r ON o.restaurant_id = r.id 
    WHERE o.user_id = ? 
    ORDER BY o.created_at DESC 
    LIMIT 10
");
$stmt->execute([$user['id']]);
$orders = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_profile') {
        $name = sanitize($_POST['name']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        
        $stmt = $db->prepare("
            UPDATE users 
            SET name = ?, phone = ?, address = ? 
            WHERE id = ?
        ");
        
        if ($stmt->execute([$name, $phone, $address, $user['id']])) {
            $success = 'Профиль успешно обновлен';
            $user = getUser();
        } else {
            $error = 'Ошибка при обновлении профиля';
        }
    }
}

$pageTitle = 'Личный кабинет';
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>Личный кабинет</h1>
        <p>Добро пожаловать, <?php echo htmlspecialchars($user['name']); ?>!</p>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="account-grid">
            <div class="account-card">
                <h2>Мой профиль</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-group">
                        <label for="name">Имя</label>
                        <input type="text" id="name" name="name" class="form-control" 
                               value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" class="form-control" 
                               value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="tel" id="phone" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Адрес доставки</label>
                        <textarea id="address" name="address" class="form-control" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Сохранить изменения</button>
                </form>
            </div>
            
            <div class="account-card">
                <h2>История заказов</h2>
                
                <?php if (empty($orders)): ?>
                    <p>У вас еще нет заказов</p>
                    <a href="<?php echo BASE_URL; ?>/" class="btn btn-primary">Сделать заказ</a>
                <?php else: ?>
                    <div class="order-history">
                        <?php foreach ($orders as $order): ?>
                        <div class="order-card">
                            <div style="display: flex; justify-content: space-between; align-items: start;">
                                <div>
                                    <h3>Заказ #<?php echo $order['id']; ?></h3>
                                    <p style="color: #666; font-size: 0.9rem;">
                                        <?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?>
                                    </p>
                                </div>
                                <span class="order-status status-<?php echo $order['status']; ?>">
                                    <?php 
                                        $statuses = [
                                            'pending' => 'Ожидает',
                                            'processing' => 'В обработке',
                                            'delivering' => 'Доставляется',
                                            'delivered' => 'Доставлен',
                                            'cancelled' => 'Отменен'
                                        ];
                                        echo $statuses[$order['status']] ?? $order['status'];
                                    ?>
                                </span>
                            </div>
                            
                            <p><strong>Ресторан:</strong> <?php echo htmlspecialchars($order['restaurant_name']); ?></p>
                            <p><strong>Адрес:</strong> <?php echo htmlspecialchars($order['delivery_address']); ?></p>
                            <p><strong>Сумма:</strong> <?php echo formatPrice($order['total_amount']); ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- Внутри цикла заказов в account.php -->
                    <div class="order-actions">
                        <a href="<?php echo BASE_URL; ?>/order-track.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-truck"></i> Отследить
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>