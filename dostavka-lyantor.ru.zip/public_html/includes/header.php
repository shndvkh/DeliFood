<?php
require_once __DIR__ . '/config.php';
$user = getUser();
$cartCount = getCartCount();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        window.addToCartAjax = function(dishId, button = null) {
            if (button) {
                const originalHtml = button.innerHTML;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                button.disabled = true;
                
                setTimeout(() => {
                    button.innerHTML = originalHtml;
                    button.disabled = false;
                }, 1000);
            }
            
            fetch('api/cart.php?action=add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    dish_id: dishId,
                    quantity: 1
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.updateCartCount(data.count);
                    
                    window.showNotification('Товар добавлен в корзину', 'success');
                } else {
                    window.showNotification('Ошибка: ' + (data.error || 'Неизвестная ошибка'), 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                window.showNotification('Ошибка при добавлении в корзину', 'error');
            });
        };
        
        window.updateCartCount = function(count) {
            const cartCount = document.querySelector('.cart-count');
            if (cartCount) {
                cartCount.textContent = count;
            } else {
                const cartBtn = document.querySelector('.cart-btn');
                if (cartBtn) {
                    const countSpan = document.createElement('span');
                    countSpan.className = 'cart-count';
                    countSpan.textContent = count;
                    cartBtn.appendChild(countSpan);
                }
            }
        };
        
        window.showNotification = function(message, type = 'success') {
            const existingNotification = document.querySelector('.notification');
            if (existingNotification) {
                existingNotification.remove();
            }
            
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                <span>${message}</span>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.classList.add('show');
            }, 10);
            
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }, 3000);
        };
        
        document.addEventListener('click', function(e) {
            const cartButton = e.target.closest('.cart-button');
            if (cartButton) {
                e.preventDefault();
                e.stopPropagation();
                
                const dishId = cartButton.dataset.id;
                window.addToCartAjax(dishId, cartButton);
            }
        });
        
        if (!document.querySelector('#notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                display: flex;
                align-items: center;
                gap: 10px;
                z-index: 1000;
                transform: translateX(120%);
                transition: transform 0.3s ease;
                max-width: 300px;
            }

            .notification.show {
                transform: translateX(0);
            }

            .notification-success {
                border-left: 4px solid #4CAF50;
            }

            .notification-error {
                border-left: 4px solid #f44336;
            }

            .notification i {
                font-size: 1.2rem;
            }

            .notification-success i {
                color: #4CAF50;
            }

            .notification-error i {
                color: #f44336;
            }

            .notification span {
                font-size: 0.95rem;
            }
            `;
            document.head.appendChild(style);
        }
    });
    </script>


</head>
<body>
    <header class="site-header">
        <nav class="navbar">
            <div class="container">
                <a href="<?php echo BASE_URL; ?>/" class="logo">
                    <i class="fas fa-utensils"></i>
                    <span><?php echo SITE_NAME; ?></span>
                </a>
                
                <div class="burger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                
                <ul class="nav-menu">
                    <li><a href="<?php echo BASE_URL; ?>/" class="nav-link">Главная</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/search.php" class="nav-link">Рестораны</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/cart.php" class="nav-link">Корзина</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/reviews.php" class="nav-link">Отзывы</a></li>
                    <?php if ($user): ?>
                        <li><a href="<?php echo BASE_URL; ?>/account.php" class="nav-link">Кабинет</a></li>
                        <?php if ($user['email'] === 'admin@dostavka-lyantor.ru'): ?>
                            <li><a href="<?php echo BASE_URL; ?>/admin/" class="nav-link">Админ-Панель</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo BASE_URL; ?>/logout.php" class="nav-link">Выйти</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo BASE_URL; ?>/login.php" class="nav-link">Войти</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/register.php" class="nav-link">Регистрация</a></li>
                    <?php endif; ?>
                </ul>
                
                <div class="nav-actions">
                    <a href="<?php echo BASE_URL; ?>/cart.php" class="cart-btn">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($cartCount > 0): ?>
                            <span class="cart-count"><?php echo $cartCount; ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </nav>
    </header>
    <main class="main-content">