// Основной JavaScript файл
document.addEventListener('DOMContentLoaded', function() {
    // Мобильное меню
    const burger = document.querySelector('.burger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (burger && navMenu) {
        burger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            burger.classList.toggle('active');
            
            // Анимация бургера
            const spans = burger.querySelectorAll('span');
            if (burger.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
        
        // Закрытие меню при клике на ссылку
        navMenu.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                burger.classList.remove('active');
            });
        });
    }
    
    // Добавление в корзину
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const dishId = this.dataset.id;
            addToCart(dishId);
        });
    });
    

    

    // Альтернативный вариант с AJAX (если хотите)
    async function searchRestaurants(address) {
        try {
            const response = await fetch(`api/search.php?address=${encodeURIComponent(address)}`);
            
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            
            const data = await response.json();
            
            if (data.success && data.restaurants.length > 0) {
                // Показываем результаты поиска
                showSearchResults(data.restaurants, address);
            } else {
                showNotification('Рестораны не найдены по этому адресу', 'warning');
            }
        } catch (error) {
            console.error('Ошибка поиска ресторанов:', error);
            showNotification('Ошибка поиска ресторанов', 'error');
        }
    }

    function showSearchResults(restaurants, address) {
        // Создаем модальное окно с результатами
        const modal = document.createElement('div');
        modal.className = 'search-results-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h2>Рестораны по адресу: ${address}</h2>
                <p>Найдено ${restaurants.length} ресторанов</p>
                <div class="results-list">
                    ${restaurants.map(restaurant => `
                        <div class="restaurant-item">
                            <img src="${BASE_URL}/assets/img/restaurants/${restaurant.image || 'default.jpg'}" 
                                alt="${restaurant.name}">
                            <div>
                                <h3>${restaurant.name}</h3>
                                <p>${restaurant.cuisine} • ${restaurant.delivery_time}</p>
                                <span class="rating">★ ${restaurant.rating}</span>
                                <a href="#" class="btn btn-sm btn-primary" data-id="${restaurant.id}">Выбрать</a>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <button class="btn btn-secondary close-modal">Закрыть</button>
            </div>
        `;
        
        // Стили для модального окна
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            padding: 20px;
        `;
        
        modal.querySelector('.modal-content').style.cssText = `
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 800px;
            width: 100%;
            max-height: 80vh;
            overflow-y: auto;
        `;
        
        // Закрытие модального окна
        modal.querySelector('.close-modal').addEventListener('click', () => {
            modal.remove();
        });
        
        // Клик вне модального окна
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
        
        // Выбор ресторана
        modal.querySelectorAll('.btn[data-id]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const restaurantId = btn.dataset.id;
                // Переход на страницу ресторана
                window.location.href = `restaurant.php?id=${restaurantId}`;
            });
        });
        
        document.body.appendChild(modal);
    }

    
    // Плавная прокрутка для якорных ссылок
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            if (this.getAttribute('href') === '#') return;
            
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Инициализация корзины
    updateCartCount();
    
    // AJAX обработка только для форм с атрибутом data-ajax="true"
    document.addEventListener('submit', function(e) {
        const form = e.target;
        
        // Проверяем, является ли это формой входа или регистрации
        const isLoginForm = window.location.pathname.includes('login.php');
        const isRegisterForm = window.location.pathname.includes('register.php');
        const isAuthForm = isLoginForm || isRegisterForm;
        
        // Если это форма входа/регистрации - пропускаем AJAX обработку
        if (isAuthForm) {
            return true;
        }
        
        // Для остальных форм проверяем атрибут data-ajax
        if (form.getAttribute('data-ajax') === 'true') {
            e.preventDefault();
            
            if (validateForm(form)) {
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Отправка...';
                submitBtn.disabled = true;
                
                const formData = new FormData(form);
                
                fetch(form.action, {
                    method: form.method,
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        showNotification(data.message || 'Успешно!');
                        
                        if (data.redirect) {
                            setTimeout(() => {
                                window.location.href = data.redirect;
                            }, 1500);
                        }
                        
                        if (data.clearForm) {
                            form.reset();
                        }
                    } else {
                        showNotification(data.error || 'Ошибка!', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Ошибка соединения с сервером', 'error');
                })
                .finally(() => {
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                });
            }
        }
    });
});

// Функции для работы с корзиной
async function addToCart(dishId) {
    try {
        const response = await fetch('api/cart.php?action=add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                dish_id: dishId,
                quantity: 1
            })
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Товар добавлен в корзину!');
            updateCartCount();
            
            if (window.location.pathname.includes('cart.php')) {
                location.reload();
            }
        } else {
            showNotification('Ошибка: ' + data.error, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Ошибка соединения с сервером', 'error');
    }
}

async function updateCartCount() {
    try {
        const response = await fetch('api/cart.php?action=count');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        
        if (data.success) {
            const cartCountElements = document.querySelectorAll('.cart-count');
            cartCountElements.forEach(el => {
                if (data.count > 0) {
                    el.textContent = data.count;
                    el.style.display = 'flex';
                } else {
                    el.style.display = 'none';
                }
            });
        }
    } catch (error) {
        console.error('Error updating cart count:', error);
    }
}

// Валидация форм
function validateForm(form) {
    let isValid = true;
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            highlightError(input);
        } else {
            removeError(input);
            
            // Специальная валидация для email
            if (input.type === 'email') {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value)) {
                    isValid = false;
                    highlightError(input, 'Введите корректный email');
                }
            }
        }
    });
    
    return isValid;
}

function highlightError(input, message = 'Это поле обязательно для заполнения') {
    input.style.borderColor = '#f44336';
    
    // Удаляем старое сообщение об ошибке
    const oldError = input.parentNode.querySelector('.error-message');
    if (oldError) oldError.remove();
    
    // Создаем новое сообщение об ошибке
    const errorSpan = document.createElement('span');
    errorSpan.className = 'error-message';
    errorSpan.style.cssText = `
        color: #f44336;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    `;
    errorSpan.textContent = message;
    
    input.parentNode.appendChild(errorSpan);
}

function removeError(input) {
    input.style.borderColor = '';
    const errorSpan = input.parentNode.querySelector('.error-message');
    if (errorSpan) errorSpan.remove();
}

// Уведомления
function showNotification(message, type = 'success') {
    // Удаляем старые уведомления
    const oldNotifications = document.querySelectorAll('.notification');
    oldNotifications.forEach(n => n.remove());
    
    // Создаем новое уведомление
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Стили уведомления
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background-color: ${type === 'error' ? '#f44336' : '#4caf50'};
        color: white;
        border-radius: 5px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Автоматическое скрытие
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
    
    // Добавляем стили для анимации
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
}