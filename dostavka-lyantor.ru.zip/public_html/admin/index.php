<?php
require_once __DIR__ . '/../includes/config.php';

// Проверка на администратора
if (!isLoggedIn()) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = getUser();
$adminEmails = ['admin@dostavka-lyantor.ru']; // Почты которые будут видеть пользователя администратором

if (!in_array($user['email'], $adminEmails)) {
    header('Location: /');
    exit();
}

$db = getDB();
$action = $_GET['action'] ?? 'dashboard';

// Включаем админский header
require_once __DIR__ . '/header.php';

// Включаем файл действия
switch ($action) {
    case 'dashboard':
        include 'dashboard.php';
        break;
    case 'orders':
        include 'orders.php';
        break;
    case 'restaurants':
        include 'restaurants.php';
        break;
    case 'dishes':
        include 'dishes.php';
        break;
    case 'users':
        include 'users.php';
        break;
    case 'reviews':
        include 'reviews.php';
        break;
    default:
        include 'dashboard.php';
}

// Включаем админский footer
require_once __DIR__ . '/footer.php';
?>