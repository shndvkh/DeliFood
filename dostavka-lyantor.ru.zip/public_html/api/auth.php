<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $email = sanitize($data['email'] ?? '');
            $password = $data['password'] ?? '';
            
            if (empty($email) || empty($password)) {
                echo json_encode(['success' => false, 'error' => 'Все поля обязательны']);
                exit;
            }
            
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && verifyPassword($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Вход выполнен успешно',
                    'redirect' => BASE_URL . '/account.php'
                ]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Неверный email или пароль']);
            }
        }
        break;
        
    case 'register':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $name = sanitize($data['name'] ?? '');
            $email = sanitize($data['email'] ?? '');
            $password = $data['password'] ?? '';
            $confirm_password = $data['confirm_password'] ?? '';
            $phone = sanitize($data['phone'] ?? '');
            
            if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
                echo json_encode(['success' => false, 'error' => 'Все поля обязательны']);
                exit;
            }
            
            if ($password !== $confirm_password) {
                echo json_encode(['success' => false, 'error' => 'Пароли не совпадают']);
                exit;
            }
            
            if (!validateEmail($email)) {
                echo json_encode(['success' => false, 'error' => 'Неверный формат email']);
                exit;
            }
            
            $db = getDB();
            
            // Проверка существования email
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Пользователь с таким email уже существует']);
                exit;
            }
            
            $hashedPassword = hashPassword($password);
            
            $stmt = $db->prepare("
                INSERT INTO users (name, email, password, phone, created_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            
            if ($stmt->execute([$name, $email, $hashedPassword, $phone])) {
                $userId = $db->lastInsertId();
                $_SESSION['user_id'] = $userId;
                $_SESSION['user_name'] = $name;
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Регистрация успешна',
                    'redirect' => BASE_URL . '/account.php'
                ]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Ошибка при регистрации']);
            }
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Неизвестное действие']);
}
?>