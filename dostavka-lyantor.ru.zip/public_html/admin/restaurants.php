<?php
$db = getDB();

$message = '';
$messageType = '';

// ОБРАБОТКА УДАЛЕНИЯ РЕСТОРАНА
if (isset($_GET['delete'])) {
    $restaurantId = intval($_GET['delete']);
    
    $db->beginTransaction();
    try {
        // Сначала удаляем связанные блюда
        $stmt = $db->prepare("DELETE FROM dishes WHERE restaurant_id = ?");
        $stmt->execute([$restaurantId]);
        
        // Затем удаляем ресторан
        $stmt = $db->prepare("DELETE FROM restaurants WHERE id = ?");
        $stmt->execute([$restaurantId]);
        
        $db->commit();
        $message = 'Ресторан успешно удален';
        $messageType = 'success';
    } catch (Exception $e) {
        $db->rollBack();
        $message = 'Ошибка при удалении ресторана';
        $messageType = 'error';
    }
}

// ПРОСМОТР/РЕДАКТИРОВАНИЕ КОНКРЕТНОГО РЕСТОРАНА
if (isset($_GET['edit'])) {
    $restaurantId = intval($_GET['edit']);
    $restaurant = null;
    
    if ($restaurantId) {
        $stmt = $db->prepare("SELECT * FROM restaurants WHERE id = ?");
        $stmt->execute([$restaurantId]);
        $restaurant = $stmt->fetch();
    }
    
    // Сохранение изменений
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_restaurant'])) {
        // Получаем данные из формы, только обрезаем пробелы
        // НЕ используем htmlspecialchars при сохранении в БД
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $cuisine = trim($_POST['cuisine'] ?? '');
        $deliveryTime = trim($_POST['delivery_time'] ?? '30-40 мин');
        $active = isset($_POST['active']) ? 1 : 0;
        
        if ($restaurantId) {
            // Обновление
            $stmt = $db->prepare("
                UPDATE restaurants 
                SET name = ?, description = ?, cuisine = ?, delivery_time = ?, active = ?
                WHERE id = ?
            ");
            if ($stmt->execute([$name, $description, $cuisine, $deliveryTime, $active, $restaurantId])) {
                $message = 'Изменения сохранены';
                $messageType = 'success';
                // Обновляем данные
                $stmt = $db->prepare("SELECT * FROM restaurants WHERE id = ?");
                $stmt->execute([$restaurantId]);
                $restaurant = $stmt->fetch();
            }
        } else {
            // Создание нового
            $stmt = $db->prepare("
                INSERT INTO restaurants (name, description, cuisine, delivery_time, active, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            if ($stmt->execute([$name, $description, $cuisine, $deliveryTime, $active])) {
                $message = 'Ресторан успешно создан';
                $messageType = 'success';
                $restaurantId = $db->lastInsertId();
                // Загружаем данные
                $stmt = $db->prepare("SELECT * FROM restaurants WHERE id = ?");
                $stmt->execute([$restaurantId]);
                $restaurant = $stmt->fetch();
            }
        }
    }
    ?>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h1><?php echo $restaurant ? 'Редактирование ресторана' : 'Новый ресторан'; ?></h1>
        <a href="?action=restaurants" class="btn btn-outline">← Назад к списку</a>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>" style="margin-bottom: 20px;">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="" style="max-width: 600px;">
        <input type="hidden" name="save_restaurant" value="1">
        
        <div class="form-group">
            <label for="name">Название ресторана *</label>
            <input type="text" id="name" name="name" class="form-control" 
                   value="<?php echo htmlspecialchars($restaurant['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="description">Описание</label>
            <textarea id="description" name="description" class="form-control" rows="3"><?php 
                echo htmlspecialchars($restaurant['description'] ?? '', ENT_QUOTES, 'UTF-8'); 
            ?></textarea>
        </div>
        
        <div class="form-group">
            <label for="cuisine">Кухня</label>
            <input type="text" id="cuisine" name="cuisine" class="form-control" 
                   value="<?php echo htmlspecialchars($restaurant['cuisine'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        
        <div class="form-group">
            <label for="delivery_time">Время доставки</label>
            <input type="text" id="delivery_time" name="delivery_time" class="form-control" 
                   value="<?php echo htmlspecialchars($restaurant['delivery_time'] ?? '30-40 мин', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        
        <div class="form-group">
            <label class="checkbox">
                <input type="checkbox" name="active" value="1" 
                       <?php echo ($restaurant && $restaurant['active']) || !$restaurant ? 'checked' : ''; ?>>
                <span>Активен</span>
            </label>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Сохранить</button>
            <?php if ($restaurant): ?>
                <button type="button" 
                        onclick="if(confirm('Удалить ресторан? Все связанные блюда также будут удалены.')) window.location.href='?action=restaurants&delete=<?php echo $restaurant['id']; ?>'"
                        class="btn btn-danger">
                    Удалить
                </button>
            <?php endif; ?>
        </div>
    </form>
    
    <?php if ($restaurant): ?>
    <div style="margin-top: 40px;">
        <h3>Меню ресторана</h3>
        <a href="?action=dishes&restaurant_id=<?php echo $restaurant['id']; ?>" class="btn btn-outline">
            Управление блюдами
        </a>
    </div>
    <?php endif;
    
    return;
}

// СПИСОК РЕСТОРАНОВ
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Получаем рестораны
$stmt = $db->query("SELECT * FROM restaurants ORDER BY id DESC LIMIT $limit OFFSET $offset");
$restaurants = $stmt->fetchAll();

// Общее количество
$stmt = $db->query("SELECT COUNT(*) as total FROM restaurants");
$totalRestaurants = $stmt->fetch()['total'];
$totalPages = ceil($totalRestaurants / $limit);
?>

<h1>Управление ресторанами</h1>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <a href="?action=restaurants&edit=0" class="btn btn-primary">
        <i class="fas fa-plus"></i> Добавить ресторан
    </a>
    
    <div>
        Всего ресторанов: <strong><?php echo htmlspecialchars($totalRestaurants); ?></strong>
    </div>
</div>

<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Название</th>
                <th>Кухня</th>
                <th>Время доставки</th>
                <th>Рейтинг</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($restaurants as $restaurant): ?>
            <tr>
                <td><?php echo htmlspecialchars($restaurant['id']); ?></td>
                <td>
                    <strong><?php echo htmlspecialchars($restaurant['name'], ENT_QUOTES, 'UTF-8'); ?></strong>
                    <?php if ($restaurant['description']): ?>
                        <p style="margin: 5px 0 0 0; color: #666; font-size: 0.9rem;">
                            <?php 
                            $description = htmlspecialchars($restaurant['description'], ENT_QUOTES, 'UTF-8');
                            echo mb_strlen($description) > 50 
                                ? mb_substr($description, 0, 50) . '...' 
                                : $description; 
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
                <td><?php echo htmlspecialchars($restaurant['cuisine'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($restaurant['delivery_time'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td>
                    <span class="rating" style="color: #FFC107; font-weight: bold;">
                        <i class="fas fa-star"></i> <?php echo htmlspecialchars($restaurant['rating'] ?? '0.0'); ?>
                    </span>
                </td>
                <td>
                    <span class="status-badge <?php echo $restaurant['active'] ? 'status-delivered' : 'status-cancelled'; ?>">
                        <?php echo $restaurant['active'] ? 'Активен' : 'Неактивен'; ?>
                    </span>
                </td>
                <td>
                    <a href="?action=restaurants&edit=<?php echo htmlspecialchars($restaurant['id']); ?>" 
                       class="btn-admin btn-edit" title="Редактировать">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a href="?action=dishes&restaurant_id=<?php echo htmlspecialchars($restaurant['id']); ?>" 
                       class="btn-admin btn-primary" title="Блюда">
                        <i class="fas fa-utensils"></i>
                    </a>
                    <button onclick="if(confirm('Удалить ресторан?')) window.location.href='?action=restaurants&delete=<?php echo htmlspecialchars($restaurant['id']); ?>'" 
                       class="btn-admin btn-delete" title="Удалить">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination" style="display: flex; justify-content: center; margin-top: 20px; gap: 10px;">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?action=restaurants&page=<?php echo htmlspecialchars($i); ?>" 
           class="btn btn-outline <?php echo $i == $page ? 'active' : ''; ?>">
            <?php echo htmlspecialchars($i); ?>
        </a>
    <?php endfor; ?>
</div>
<?php endif; ?>