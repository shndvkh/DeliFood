<?php
$db = getDB();

// Статистика
$stmt = $db->query("SELECT COUNT(*) as total FROM orders");
$totalOrders = $stmt->fetch()['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM orders WHERE DATE(created_at) = CURDATE()");
$todayOrders = $stmt->fetch()['total'];

$stmt = $db->query("SELECT SUM(total_amount) as total FROM orders WHERE DATE(created_at) = CURDATE()");
$todayRevenue = $stmt->fetch()['total'] ?? 0;

$stmt = $db->query("SELECT COUNT(*) as total FROM users");
$totalUsers = $stmt->fetch()['total'];

$stmt = $db->query("SELECT COUNT(*) as total FROM restaurants WHERE active = TRUE");
$activeRestaurants = $stmt->fetch()['total'];

// Последние заказы
$stmt = $db->query("
    SELECT o.*, u.name as user_name, r.name as restaurant_name 
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.id 
    LEFT JOIN restaurants r ON o.restaurant_id = r.id 
    ORDER BY o.created_at DESC 
    LIMIT 10
");
$recentOrders = $stmt->fetchAll();
?>

<h1>Dashboard</h1>
<p>Обзор статистики и последних событий</p>

<div class="admin-stats">
    <div class="stat-card">
        <i class="fas fa-shopping-cart"></i>
        <h3><?php echo $totalOrders; ?></h3>
        <p>Всего заказов</p>
    </div>
    
    <div class="stat-card">
        <i class="fas fa-calendar-day"></i>
        <h3><?php echo $todayOrders; ?></h3>
        <p>Заказов сегодня</p>
    </div>
    
    <div class="stat-card">
        <i class="fas fa-money-bill-wave"></i>
        <h3><?php echo formatPrice($todayRevenue); ?></h3>
        <p>Выручка сегодня</p>
    </div>
    
    <div class="stat-card">
        <i class="fas fa-users"></i>
        <h3><?php echo $totalUsers; ?></h3>
        <p>Пользователей</p>
    </div>
    
    <div class="stat-card">
        <i class="fas fa-utensils"></i>
        <h3><?php echo $activeRestaurants; ?></h3>
        <p>Активных ресторанов</p>
    </div>
</div>

<h2>Последние заказы</h2>
<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Клиент</th>
                <th>Ресторан</th>
                <th>Сумма</th>
                <th>Статус</th>
                <th>Дата</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($recentOrders as $order): ?>
            <tr>
                <td>#<?php echo $order['id']; ?></td>
                <td><?php echo htmlspecialchars($order['user_name']); ?></td>
                <td><?php echo htmlspecialchars($order['restaurant_name']); ?></td>
                <td><?php echo formatPrice($order['total_amount']); ?></td>
                <td>
                    <span class="status-badge status-<?php echo $order['status']; ?>">
                        <?php 
                        $statuses = [
                            'pending' => 'Ожидает',
                            'processing' => 'В обработке',
                            'delivering' => 'Доставляется',
                            'delivered' => 'Доставлен',
                            'cancelled' => 'Отменен'
                        ];
                        echo $statuses[$order['status']];
                        ?>
                    </span>
                </td>
                <td><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                <td>
                    <a href="?action=orders&view=<?php echo $order['id']; ?>" class="btn-admin btn-edit">
                        <i class="fas fa-eye"></i>
                    </a>
                    <button onclick="updateStatus(<?php echo $order['id']; ?>)" class="btn-admin btn-status">
                        <i class="fas fa-sync"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
function updateStatus(orderId) {
    const newStatus = prompt('Введите новый статус (pending, processing, delivering, delivered, cancelled):');
    if (newStatus) {
        fetch('../api/orders.php?id=' + orderId, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ status: newStatus })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Статус обновлен');
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
            }
        });
    }
}
</script>