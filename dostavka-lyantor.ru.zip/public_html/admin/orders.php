<?php
$db = getDB();

$message = '';
$messageType = '';

// Обновление статуса заказа
if (isset($_GET['update_status'])) {
    $orderId = intval($_GET['update_status']);
    $status = $_GET['status'] ?? '';
    
    $allowedStatuses = ['pending', 'processing', 'delivering', 'delivered', 'cancelled'];
    
    if ($orderId && in_array($status, $allowedStatuses)) {
        $stmt = $db->prepare("UPDATE orders SET status = ? WHERE id = ?");
        if ($stmt->execute([$status, $orderId])) {
            $message = 'Статус заказа обновлен';
            $messageType = 'success';
        } else {
            $message = 'Ошибка обновления статуса';
            $messageType = 'error';
        }
    }
}

// Просмотр конкретного заказа
if (isset($_GET['view'])) {
    $orderId = intval($_GET['view']);
    
    $stmt = $db->prepare("
        SELECT o.*, 
               u.name as user_name, 
               u.email as user_email,
               u.phone as user_phone,
               r.name as restaurant_name
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        LEFT JOIN restaurants r ON o.restaurant_id = r.id 
        WHERE o.id = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
    
    if (!$order) {
        echo '<div class="alert alert-error">Заказ не найден</div>';
        return;
    }
    
    // Получаем элементы заказа
    $stmt = $db->prepare("
        SELECT oi.*, 
               d.name as dish_name,
               d.image as dish_image
        FROM order_items oi
        LEFT JOIN dishes d ON oi.dish_id = d.id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $orderItems = $stmt->fetchAll();
    ?>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h1>Заказ #<?php echo $order['id']; ?></h1>
        <a href="?action=orders" class="btn btn-outline">← Назад к списку</a>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <div class="order-details-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
        <div class="info-card">
            <h3><i class="fas fa-user"></i> Информация о клиенте</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="label">Имя:</span>
                    <span class="value"><?php echo htmlspecialchars($order['user_name']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Email:</span>
                    <span class="value"><?php echo htmlspecialchars($order['user_email']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Телефон:</span>
                    <span class="value"><?php echo htmlspecialchars($order['user_phone']); ?></span>
                </div>
            </div>
        </div>
        
        <div class="info-card">
            <h3><i class="fas fa-utensils"></i> Информация о заказе</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="label">Статус:</span>
                    <span class="value">
                        <select id="statusSelect" style="padding: 5px; border-radius: 5px; border: 1px solid #ddd;">
                            <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Ожидает</option>
                            <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>В обработке</option>
                            <option value="delivering" <?php echo $order['status'] == 'delivering' ? 'selected' : ''; ?>>Доставляется</option>
                            <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Доставлен</option>
                            <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Отменен</option>
                        </select>
                        <button onclick="updateOrderStatus(<?php echo $order['id']; ?>)" class="btn btn-primary btn-sm">Обновить</button>
                    </span>
                </div>
                <div class="info-item">
                    <span class="label">Ресторан:</span>
                    <span class="value"><?php echo htmlspecialchars($order['restaurant_name']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Дата создания:</span>
                    <span class="value"><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></span>
                </div>
            </div>
        </div>
        
        <div class="info-card">
            <h3><i class="fas fa-map-marker-alt"></i> Доставка</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="label">Адрес:</span>
                    <span class="value"><?php echo htmlspecialchars($order['delivery_address']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Способ оплаты:</span>
                    <span class="value">
                        <?php 
                        $paymentMethods = [
                            'cash' => 'Наличными',
                            'card' => 'Картой онлайн',
                            'card_courier' => 'Картой курьеру'
                        ];
                        echo $paymentMethods[$order['payment_method']] ?? $order['payment_method'];
                        ?>
                    </span>
                </div>
                <div class="info-item">
                    <span class="label">Комментарий:</span>
                    <span class="value"><?php echo $order['comment'] ? htmlspecialchars($order['comment']) : '—'; ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="order-items-card">
        <h3><i class="fas fa-receipt"></i> Состав заказа</h3>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Блюдо</th>
                    <th>Количество</th>
                    <th>Цена за единицу</th>
                    <th>Итого</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderItems as $item): ?>
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <img src="<?php echo ASSETS_URL; ?>/assets/img/dishes/<?php echo $item['dish_image'] ?: 'default.jpg'; ?>" 
                                 style="width: 50px; height: 50px; border-radius: 5px; object-fit: cover;">
                            <span><?php echo htmlspecialchars($item['dish_name']); ?></span>
                        </div>
                    </td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><?php echo formatPrice($item['price']); ?></td>
                    <td><?php echo formatPrice($item['price'] * $item['quantity']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="order-summary" style="text-align: right; margin-top: 20px;">
            <div style="display: inline-block; text-align: left;">
                <p><strong>Сумма заказа:</strong> <?php echo formatPrice($order['total_amount'] - 200); ?></p>
                <p><strong>Доставка:</strong> 200 ₽</p>
                <p style="font-size: 1.2rem; font-weight: bold; color: #FF5722;">
                    <strong>Итого:</strong> <?php echo formatPrice($order['total_amount']); ?>
                </p>
            </div>
        </div>
    </div>
    
    <script>
    function updateOrderStatus(orderId) {
        const status = document.getElementById('statusSelect').value;
        window.location.href = `?action=orders&update_status=${orderId}&status=${status}`;
    }
    </script>
    
    <?php
    return;
}

// Список заказов
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Фильтры
$where = [];
$params = [];

if (isset($_GET['status']) && $_GET['status']) {
    $where[] = "o.status = ?";
    $params[] = $_GET['status'];
}

if (isset($_GET['date_from']) && $_GET['date_from']) {
    $where[] = "DATE(o.created_at) >= ?";
    $params[] = $_GET['date_from'];
}

if (isset($_GET['date_to']) && $_GET['date_to']) {
    $where[] = "DATE(o.created_at) <= ?";
    $params[] = $_GET['date_to'];
}

$whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";

// Общее количество
$countSql = "SELECT COUNT(*) as total FROM orders o $whereClause";
$countStmt = $db->prepare($countSql);
if (!empty($params)) {
    $countStmt->execute($params);
} else {
    $countStmt->execute();
}
$totalOrders = $countStmt->fetch()['total'];
$totalPages = ceil($totalOrders / $limit);

// Получаем заказы
$sql = "
    SELECT o.*, u.name as user_name, r.name as restaurant_name 
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.id 
    LEFT JOIN restaurants r ON o.restaurant_id = r.id 
    $whereClause
    ORDER BY o.created_at DESC 
    LIMIT " . (int)$limit . " OFFSET " . (int)$offset;

$stmt = $db->prepare($sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$orders = $stmt->fetchAll();
?>

<h1>Управление заказами</h1>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>"><?php echo $message; ?></div>
<?php endif; ?>

<div class="filters" style="background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
    <form method="GET" action="">
        <input type="hidden" name="action" value="orders">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <div>
                <label>Статус:</label>
                <select name="status" class="form-control">
                    <option value="">Все статусы</option>
                    <option value="pending" <?php echo ($_GET['status'] ?? '') == 'pending' ? 'selected' : ''; ?>>Ожидает</option>
                    <option value="processing" <?php echo ($_GET['status'] ?? '') == 'processing' ? 'selected' : ''; ?>>В обработке</option>
                    <option value="delivering" <?php echo ($_GET['status'] ?? '') == 'delivering' ? 'selected' : ''; ?>>Доставляется</option>
                    <option value="delivered" <?php echo ($_GET['status'] ?? '') == 'delivered' ? 'selected' : ''; ?>>Доставлен</option>
                    <option value="cancelled" <?php echo ($_GET['status'] ?? '') == 'cancelled' ? 'selected' : ''; ?>>Отменен</option>
                </select>
            </div>
            <div>
                <label>Дата от:</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo $_GET['date_from'] ?? ''; ?>">
            </div>
            <div>
                <label>Дата до:</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo $_GET['date_to'] ?? ''; ?>">
            </div>
            <div style="display: flex; align-items: flex-end;">
                <button type="submit" class="btn btn-primary">Фильтровать</button>
                <a href="?action=orders" class="btn btn-outline" style="margin-left: 10px;">Сбросить</a>
            </div>
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Клиент</th>
                <th>Ресторан</th>
                <th>Сумма</th>
                <th>Адрес</th>
                <th>Статус</th>
                <th>Дата</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td>#<?php echo $order['id']; ?></td>
                <td><?php echo htmlspecialchars($order['user_name']); ?></td>
                <td><?php echo htmlspecialchars($order['restaurant_name']); ?></td>
                <td><?php echo formatPrice($order['total_amount']); ?></td>
                <td title="<?php echo htmlspecialchars($order['delivery_address']); ?>">
                    <?php echo mb_strlen($order['delivery_address']) > 30 ? mb_substr($order['delivery_address'], 0, 30) . '...' : htmlspecialchars($order['delivery_address']); ?>
                </td>
                <td>
                    <span class="status-badge status-<?php echo $order['status']; ?>">
                        <?php 
                        $statuses = [
                            'pending' => 'Ожидает',
                            'processing' => 'В обработке',
                            'delivering' => 'Доставляется',
                            'delivered' => 'Доставлен',
                            'cancelled' => 'Отменен'
                        ];
                        echo $statuses[$order['status']];
                        ?>
                    </span>
                </td>
                <td><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                <td>
                    <a href="?action=orders&view=<?php echo $order['id']; ?>" class="btn-admin btn-edit" title="Просмотр">
                        <i class="fas fa-eye"></i>
                    </a>
                    <button onclick="updateStatus(<?php echo $order['id']; ?>)" class="btn-admin btn-status" title="Изменить статус">
                        <i class="fas fa-edit"></i>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination" style="display: flex; justify-content: center; margin-top: 20px; gap: 10px;">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?action=orders&page=<?php echo $i; ?><?php echo isset($_GET['status']) ? '&status=' . $_GET['status'] : ''; ?><?php echo isset($_GET['date_from']) ? '&date_from=' . $_GET['date_from'] : ''; ?><?php echo isset($_GET['date_to']) ? '&date_to=' . $_GET['date_to'] : ''; ?>" 
           class="btn btn-outline <?php echo $i == $page ? 'active' : ''; ?>">
            <?php echo $i; ?>
        </a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<script>
function updateStatus(orderId) {
    const newStatus = prompt('Введите новый статус (pending, processing, delivering, delivered, cancelled):');
    if (newStatus) {
        window.location.href = `?action=orders&update_status=${orderId}&status=${newStatus}`;
    }
}
</script>