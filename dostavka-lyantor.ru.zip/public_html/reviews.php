<?php
require_once __DIR__ . '/includes/config.php';

$db = getDB();

$stmt = $db->query("
    SELECT r.*, 
           u.name as user_name,
           u.email as user_email,
           res.name as restaurant_name,
           res.image as restaurant_image
    FROM reviews r
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN restaurants res ON r.restaurant_id = res.id
    ORDER BY r.created_at DESC
    LIMIT 50
");
$reviews = $stmt->fetchAll();

$stmt = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN rating >= 4 THEN 1 ELSE 0 END) as happy_clients,
        AVG(rating) as avg_rating
    FROM reviews
");
$stats = $stmt->fetch();

$totalReviews = $stats['total'] ?? 0;
$happyClients = $stats['happy_clients'] ?? 0;
$avgRating = $stats['avg_rating'] ?? 0;

$displayAvgRating = $avgRating > 0 ? number_format($avgRating, 1) : '0.0';

$pageTitle = 'Отзывы клиентов';
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>Отзывы наших клиентов</h1>
        <p>Что говорят люди о нашем сервисе</p>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <div class="reviews-stats">
            <div class="stats-card">
                <div class="stats-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stats-info">
                    <h3><?php echo $displayAvgRating; ?></h3>
                    <p>Средний рейтинг</p>
                </div>
            </div>
            <div class="stats-card">
                <div class="stats-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="stats-info">
                    <h3><?php echo $totalReviews; ?></h3>
                    <p>Всего отзывов</p>
                </div>
            </div>
            <div class="stats-card">
                <div class="stats-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stats-info">
                    <h3><?php echo $happyClients; ?></h3>
                    <p>Довольных клиентов (4-5★)</p>
                </div>
            </div>
        </div>
        
        <div class="reviews-filters">
            <h2>Последние отзывы</h2>
            <div class="filter-buttons">
                <button class="btn btn-outline active" data-rating="all">Все отзывы</button>
                <button class="btn btn-outline" data-rating="5">5 звёзд</button>
                <button class="btn btn-outline" data-rating="4">4 звезды</button>
                <button class="btn btn-outline" data-rating="3">3 звезды</button>
                <button class="btn btn-outline" data-rating="2">2 звезды</button>
                <button class="btn btn-outline" data-rating="1">1 звезда</button>
                <button class="btn btn-outline" data-rating="happy">Только довольные (4-5★)</button>
            </div>
        </div>
        
        <div class="reviews-list" id="reviewsList">
            <?php if (empty($reviews)): ?>
                <div class="no-reviews" style="text-align: center; padding: 40px; background: white; border-radius: 10px;">
                    <i class="fas fa-comments" style="font-size: 3rem; color: #ddd; margin-bottom: 20px;"></i>
                    <h3 style="color: #666; margin-bottom: 10px;">Отзывов пока нет</h3>
                    <p style="color: #999;">Будьте первым, кто оставит отзыв!</p>
                </div>
            <?php else: ?>
                <?php foreach ($reviews as $review): 
                    $isHappyClient = $review['rating'] >= 4;
                ?>
                <div class="review-card <?php echo $isHappyClient ? 'happy-client' : ''; ?>" 
                     data-rating="<?php echo $review['rating']; ?>">
                    <div class="review-header">
                        <div class="user-info">
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($review['user_name'] ?? 'A', 0, 1)); ?>
                            </div>
                            <div>
                                <h3><?php echo htmlspecialchars($review['user_name'] ?? 'Анонимный пользователь'); ?></h3>
                                <p class="review-date">
                                    <?php echo date('d.m.Y', strtotime($review['created_at'])); ?>
                                    <?php if (!empty($review['restaurant_name'])): ?>
                                        • <?php echo htmlspecialchars($review['restaurant_name']); ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                        <div class="review-rating">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'active' : ''; ?>"></i>
                            <?php endfor; ?>
                            <span class="rating-text">
                                <?php 
                                $ratingTexts = [
                                    1 => 'Ужасно',
                                    2 => 'Плохо',
                                    3 => 'Нормально',
                                    4 => 'Хорошо',
                                    5 => 'Отлично'
                                ];
                                echo $ratingTexts[$review['rating']] ?? $review['rating'] . ' звёзд';
                                ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="review-content">
                        <p><?php echo nl2br(htmlspecialchars($review['comment'] ?? '')); ?></p>
                    </div>
                    
                    <?php if (!empty($review['restaurant_name']) && !empty($review['restaurant_id'])): ?>
                    <div class="review-restaurant">
                        <div class="restaurant-info">
                            <strong>Ресторан:</strong> 
                            <a href="restaurant.php?id=<?php echo $review['restaurant_id']; ?>">
                                <?php echo htmlspecialchars($review['restaurant_name']); ?>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php if (isLoggedIn()): 
            $userId = $_SESSION['user_id'];
            
            $stmt = $db->prepare("
                SELECT COUNT(*) as today_reviews 
                FROM reviews 
                WHERE user_id = ? 
                AND DATE(created_at) = CURDATE()
            ");
            $stmt->execute([$userId]);
            $todayReviews = $stmt->fetch()['today_reviews'] ?? 0;
            
            $canReviewRestaurants = [];
            $stmt = $db->prepare("
                SELECT restaurant_id 
                FROM reviews 
                WHERE user_id = ?
            ");
            $stmt->execute([$userId]);
            $userRestaurantReviews = $stmt->fetchAll(PDO::FETCH_COLUMN);
        ?>
        <div class="add-review-section">
            <h2>Оставить отзыв</h2>
            
            <?php if ($todayReviews >= 3): ?>
                <div class="alert alert-warning">
                    <p>Вы уже оставили максимальное количество отзывов на сегодня (3). Попробуйте завтра.</p>
                </div>
            <?php else: ?>
                <div class="add-review-form">
                    <form id="addReviewForm">
                        <div class="form-group">
                            <label>Выберите ресторан (опционально)</label>
                            <select name="restaurant_id" class="form-control" id="restaurantSelect">
                                <option value="">-- Без ресторана --</option>
                                <?php 
                                $stmt = $db->query("SELECT id, name FROM restaurants WHERE active = TRUE ORDER BY name");
                                $restaurantsList = $stmt->fetchAll();
                                foreach ($restaurantsList as $r): 
                                    $alreadyReviewed = in_array($r['id'], $userRestaurantReviews);
                                ?>
                                <option value="<?php echo $r['id']; ?>" 
                                        <?php echo $alreadyReviewed ? 'disabled' : ''; ?>>
                                    <?php echo htmlspecialchars($r['name']); ?>
                                    <?php echo $alreadyReviewed ? ' (уже оставляли отзыв)' : ''; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="form-text">Вы можете оставить только один отзыв на каждый ресторан</small>
                        </div>
                        
                        <div class="form-group">
                            <label>Ваша оценка *</label>
                            <div class="rating-input">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star" data-value="<?php echo $i; ?>"></i>
                                <?php endfor; ?>
                                <input type="hidden" name="rating" id="ratingValue" value="5" required>
                                <span class="rating-label" id="ratingLabel">Отлично</span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="reviewComment">Ваш отзыв *</label>
                            <textarea id="reviewComment" name="comment" class="form-control" rows="4" required 
                                      placeholder="Поделитесь вашим опытом... (минимум 20 символов)"
                                      minlength="20" maxlength="1000"></textarea>
                            <small class="form-text">Осталось символов: <span id="charCount">1000</span></small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" 
                                <?php echo $todayReviews >= 3 ? 'disabled' : ''; ?>>
                            <?php echo $todayReviews >= 3 ? 'Лимит отзывов исчерпан' : 'Отправить отзыв'; ?>
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="alert alert-info" style="text-align: center;">
            <p>Чтобы оставить отзыв, пожалуйста, <a href="<?php echo BASE_URL; ?>/login.php">войдите</a> в систему.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.querySelectorAll('.filter-buttons button').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-buttons button').forEach(b => {
            b.classList.remove('active');
        });
        this.classList.add('active');
        
        const rating = this.dataset.rating;
        const reviews = document.querySelectorAll('.review-card');
        
        reviews.forEach(review => {
            const reviewRating = review.dataset.rating;
            const isHappy = parseInt(reviewRating) >= 4;
            
            let show = false;
            
            if (rating === 'all') {
                show = true;
            } else if (rating === 'happy') {
                show = isHappy;
            } else {
                show = reviewRating === rating;
            }
            
            review.style.display = show ? 'block' : 'none';
        });
    });
});

const ratingLabels = {
    1: 'Ужасно',
    2: 'Плохо',
    3: 'Нормально',
    4: 'Хорошо',
    5: 'Отлично'
};

document.querySelectorAll('.rating-input .fa-star').forEach(star => {
    star.addEventListener('click', function() {
        const value = this.dataset.value;
        document.getElementById('ratingValue').value = value;
        document.getElementById('ratingLabel').textContent = ratingLabels[value];
        
        document.querySelectorAll('.rating-input .fa-star').forEach(s => {
            if (s.dataset.value <= value) {
                s.classList.add('active');
            } else {
                s.classList.remove('active');
            }
        });
    });
});

const textarea = document.getElementById('reviewComment');
const charCount = document.getElementById('charCount');

if (textarea && charCount) {
    textarea.addEventListener('input', function() {
        const remaining = 1000 - this.value.length;
        charCount.textContent = remaining;
        
        if (remaining < 0) {
            charCount.style.color = '#f44336';
        } else if (remaining < 100) {
            charCount.style.color = '#ff9800';
        } else {
            charCount.style.color = '#4caf50';
        }
    });
}

const reviewForm = document.getElementById('addReviewForm');
if (reviewForm) {
    reviewForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const restaurantSelect = document.getElementById('restaurantSelect');
        const selectedRestaurant = restaurantSelect.value;
        const selectedOption = restaurantSelect.options[restaurantSelect.selectedIndex];
        
        if (selectedRestaurant && selectedOption.disabled) {
            alert('Вы уже оставляли отзыв для этого ресторана');
            return;
        }
        
        const formData = new FormData(this);
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        submitBtn.textContent = 'Отправка...';
        submitBtn.disabled = true;
        
        fetch('api/add-review.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Отзыв успешно отправлен! Спасибо за ваш отзыв.');
                this.reset();
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка отправки отзыва');
        })
        .finally(() => {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        });
    });
}
</script>

<style>
.reviews-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.stats-card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 20px;
}

.stats-icon {
    width: 60px;
    height: 60px;
    background: #FF5722;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.stats-info h3 {
    margin: 0;
    font-size: 2rem;
    color: #333;
}

.stats-info p {
    margin: 5px 0 0 0;
    color: #666;
    font-size: 0.9rem;
}

.reviews-filters {
    margin-bottom: 30px;
}

.filter-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 15px;
}

.reviews-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin-bottom: 50px;
}

.review-card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    border-left: 4px solid #FF5722;
    position: relative;
}

.review-card.happy-client {
    border-left-color: #4CAF50;
    background: linear-gradient(to right, rgba(76, 175, 80, 0.05), white);
}

.review-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
    flex-wrap: wrap;
    gap: 15px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: #FF5722;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.2rem;
}

.user-info h3 {
    margin: 0;
    font-size: 1.1rem;
}

.review-date {
    color: #666;
    font-size: 0.9rem;
    margin: 5px 0 0 0;
}

.review-rating {
    display: flex;
    align-items: center;
    gap: 10px;
}

.review-rating .fa-star {
    color: #ddd;
    font-size: 1rem;
}

.review-rating .fa-star.active {
    color: #FFC107;
}

.rating-text {
    color: #666;
    font-size: 0.9rem;
    font-weight: 600;
}

.review-content {
    margin-bottom: 15px;
}

.review-content p {
    margin: 0;
    line-height: 1.6;
    color: #333;
}

.review-restaurant {
    padding-top: 15px;
    border-top: 1px solid #eee;
}

.restaurant-info {
    font-size: 0.9rem;
    color: #666;
}

.restaurant-info a {
    color: #FF5722;
    text-decoration: none;
}

.restaurant-info a:hover {
    text-decoration: underline;
}

.happy-client-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    background: #4CAF50;
    color: white;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    gap: 5px;
}

.add-review-section {
    background: #f9f9f9;
    padding: 30px;
    border-radius: 10px;
    margin-top: 40px;
}

.rating-input {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 10px 0 20px 0;
}

.rating-input .fa-star {
    font-size: 2rem;
    color: #ddd;
    cursor: pointer;
    transition: color 0.3s;
}

.rating-input .fa-star.active,
.rating-input .fa-star:hover {
    color: #FFC107;
}

.rating-label {
    font-weight: 600;
    color: #333;
    margin-left: 10px;
}

.form-text {
    display: block;
    margin-top: 5px;
    color: #666;
    font-size: 0.85rem;
}

#charCount {
    font-weight: 600;
}

.form-check {
    margin: 20px 0;
}

.reviews-limit {
    margin-top: 15px;
    color: #666;
    font-size: 0.9rem;
    text-align: center;
}

.alert-warning {
    background: #fff3cd;
    border: 1px solid #ffeaa7;
    color: #856404;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
}

select:disabled {
    background-color: #f5f5f5;
    color: #999;
    cursor: not-allowed;
}

.no-reviews {
    text-align: center;
    padding: 40px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.no-reviews i {
    font-size: 3rem;
    color: #ddd;
    margin-bottom: 20px;
}

.no-reviews h3 {
    color: #666;
    margin-bottom: 10px;
}

.no-reviews p {
    color: #999;
}

@media (max-width: 768px) {
    .reviews-stats {
        grid-template-columns: 1fr;
    }
    
    .reviews-filters {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .review-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .happy-client-badge {
        position: relative;
        top: 0;
        right: 0;
        margin-top: 10px;
        display: inline-flex;
    }
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>