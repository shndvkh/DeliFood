<?php
require_once __DIR__ . '/includes/config.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}

$orderId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$orderId) {
    redirect(BASE_URL . '/account.php');
}

$db = getDB();
$user = getUser();

$stmt = $db->prepare("
    SELECT o.*, 
           r.name as restaurant_name,
           r.delivery_time as restaurant_delivery_time
    FROM orders o
    LEFT JOIN restaurants r ON o.restaurant_id = r.id
    WHERE o.id = ? AND o.user_id = ?
");
$stmt->execute([$orderId, $user['id']]);
$order = $stmt->fetch();

if (!$order) {
    redirect(BASE_URL . '/account.php');
}

$stmt = $db->prepare("
    SELECT oi.*, 
           d.name as dish_name,
           d.image as dish_image
    FROM order_items oi
    LEFT JOIN dishes d ON oi.dish_id = d.id
    WHERE oi.order_id = ?
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll();

$statusTexts = [
    'pending' => 'Ожидает подтверждения',
    'processing' => 'Готовится',
    'delivering' => 'В пути',
    'delivered' => 'Доставлен',
    'cancelled' => 'Отменен'
];

$statusColors = [
    'pending' => '#FF9800',
    'processing' => '#2196F3',
    'delivering' => '#4CAF50',
    'delivered' => '#607D8B',
    'cancelled' => '#F44336'
];

$pageTitle = 'Заказ успешно оформлен';
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>Заказ успешно оформлен!</h1>
        <p>Спасибо за ваш заказ. Мы уже начали его готовить.</p>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <div class="order-success-content">
            <div class="success-message">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h2>Ваш заказ принят</h2>
                <p class="order-number">Номер заказа: <strong>#<?php echo $order['id']; ?></strong></p>
                <p>Мы свяжемся с вами для подтверждения заказа в течение 10 минут.</p>
            </div>
            
            <div class="order-details-grid">
                <div class="order-info-card">
                    <h3><i class="fas fa-info-circle"></i> Информация о заказе</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="label">Статус:</span>
                            <span class="value status-badge" style="background-color: <?php echo $statusColors[$order['status']]; ?>">
                                <?php echo $statusTexts[$order['status']]; ?>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="label">Дата и время:</span>
                            <span class="value"><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="label">Ресторан:</span>
                            <span class="value"><?php echo htmlspecialchars($order['restaurant_name']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="label">Ожидаемое время доставки:</span>
                            <span class="value"><?php echo $order['restaurant_delivery_time']; ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="order-info-card">
                    <h3><i class="fas fa-map-marker-alt"></i> Доставка</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="label">Адрес:</span>
                            <span class="value"><?php echo htmlspecialchars($order['delivery_address']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="label">Способ оплаты:</span>
                            <span class="value">
                                <?php 
                                $paymentMethods = [
                                    'cash' => 'Наличными',
                                    'card' => 'Картой онлайн',
                                    'card_courier' => 'Картой курьеру'
                                ];
                                echo $paymentMethods[$order['payment_method']] ?? $order['payment_method'];
                                ?>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="label">Комментарий:</span>
                            <span class="value"><?php echo $order['comment'] ? htmlspecialchars($order['comment']) : '—'; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="order-items-card">
                <h3><i class="fas fa-utensils"></i> Состав заказа</h3>
                <div class="order-items-list">
                    <?php foreach ($orderItems as $item): ?>
                    <div class="order-item">
                        <div class="item-image">
                            <img src="<?php echo BASE_URL; ?>/assets/img/dishes/<?php echo $item['dish_image'] ?: 'default.jpg'; ?>" 
                                 alt="<?php echo htmlspecialchars($item['dish_name']); ?>">
                        </div>
                        <div class="item-info">
                            <h4><?php echo htmlspecialchars($item['dish_name']); ?></h4>
                            <p>Количество: <?php echo $item['quantity']; ?> × <?php echo formatPrice($item['price']); ?></p>
                        </div>
                        <div class="item-total">
                            <?php echo formatPrice($item['price'] * $item['quantity']); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="order-summary">
                    <div class="summary-row">
                        <span>Сумма заказа:</span>
                        <span><?php echo formatPrice($order['total_amount'] - 200); ?></span>
                    </div>
                    <div class="summary-row">
                        <span>Доставка:</span>
                        <span>200 ₽</span>
                    </div>
                    <div class="summary-row total">
                        <span>Итого к оплате:</span>
                        <span><?php echo formatPrice($order['total_amount']); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="next-steps">
                <h3>Что дальше?</h3>
                <div class="steps-timeline">
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h4>1. Подтверждение заказа</h4>
                        <p>Мы позвоним вам в течение 10 минут для подтверждения заказа</p>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h4>2. Приготовление</h4>
                        <p>Ресторан начнет готовить ваш заказ после подтверждения</p>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-truck"></i>
                        </div>
                        <h4>3. Доставка</h4>
                        <p>Курьер доставит заказ по указанному адресу</p>
                    </div>
                    <div class="step">
                        <div class="step-icon">
                            <i class="fas fa-check"></i>
                        </div>
                        <h4>4. Получение</h4>
                        <p>Получите заказ и оплатите удобным способом</p>
                    </div>
                </div>
            </div>
            
            <div class="action-buttons">
                <a href="<?php echo BASE_URL; ?>/account.php" class="btn btn-primary">
                    <i class="fas fa-history"></i> Мои заказы
                </a>
                <a href="<?php echo BASE_URL; ?>/" class="btn btn-outline">
                    <i class="fas fa-home"></i> На главную
                </a>
                <button class="btn btn-secondary" onclick="window.print()">
                    <i class="fas fa-print"></i> Распечатать
                </button>
            </div>
            
            <div class="support-info">
                <h4><i class="fas fa-headset"></i> Нужна помощь?</h4>
                <p>Если у вас есть вопросы по заказу, свяжитесь с нами:</p>
                <div class="contact-methods">
                    <p><i class="fas fa-phone"></i> Телефон: <strong>+7 (952) 123-45-67</strong></p>
                    <p><i class="fas fa-clock"></i> График работы: <strong>Круглосуточно</strong></p>
                    <p><i class="fas fa-envelope"></i> Email: <strong>support@dostavka-lyantor.ru</strong></p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.order-success-content {
    max-width: 800px;
    margin: 0 auto;
}

.success-message {
    text-align: center;
    padding: 40px 20px;
    background: linear-gradient(135deg, #4CAF50, #2E7D32);
    color: white;
    border-radius: 15px;
    margin-bottom: 30px;
}

.success-icon {
    font-size: 80px;
    margin-bottom: 20px;
    color: white;
}

.success-message h2 {
    color: white;
    margin-bottom: 10px;
}

.order-number {
    font-size: 1.2rem;
    margin-bottom: 15px;
}

.order-details-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 30px;
}

.order-info-card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.order-info-card h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
    color: #333;
}

.info-grid {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.info-item:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.label {
    color: #666;
    font-weight: 500;
    min-width: 180px;
}

.value {
    color: #333;
    text-align: right;
    flex: 1;
}

.status-badge {
    display: inline-block;
    padding: 5px 15px;
    border-radius: 20px;
    color: white;
    font-size: 0.9rem;
    font-weight: 600;
}

.order-items-card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 30px;
}

.order-items-list {
    margin-bottom: 25px;
}

.order-item {
    display: grid;
    grid-template-columns: 80px 1fr auto;
    gap: 20px;
    padding: 15px 0;
    border-bottom: 1px solid #eee;
    align-items: center;
}

.order-item:last-child {
    border-bottom: none;
}

.item-image img {
    width: 80px;
    height: 80px;
    border-radius: 8px;
    object-fit: cover;
}

.item-info h4 {
    margin: 0 0 5px 0;
    font-size: 1.1rem;
}

.item-info p {
    margin: 0;
    color: #666;
    font-size: 0.9rem;
}

.item-total {
    font-weight: bold;
    color: #FF5722;
    font-size: 1.1rem;
}

.order-summary {
    background: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    margin-top: 20px;
}

.summary-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
}

.summary-row:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
}

.summary-row.total {
    font-size: 1.3rem;
    font-weight: bold;
    color: #FF5722;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 2px solid #ddd;
}

.next-steps {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 30px;
}

.next-steps h3 {
    text-align: center;
    margin-bottom: 30px;
    color: #333;
}

.steps-timeline {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 25px;
    text-align: center;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.step-icon {
    width: 60px;
    height: 60px;
    background: #FF5722;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin-bottom: 15px;
}

.step h4 {
    margin: 0 0 10px 0;
    font-size: 1.1rem;
    color: #333;
}

.step p {
    margin: 0;
    color: #666;
    font-size: 0.9rem;
    line-height: 1.4;
}

.action-buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 30px;
}

.support-info {
    background: #f9f9f9;
    padding: 25px;
    border-radius: 10px;
    text-align: center;
}

.support-info h4 {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    margin-bottom: 15px;
    color: #333;
}

.contact-methods {
    display: flex;
    flex-direction: column;
    gap: 10px;
    align-items: center;
}

.contact-methods p {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

@media (max-width: 768px) {
    .order-details-grid {
        grid-template-columns: 1fr;
    }
    
    .order-item {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .info-item {
        flex-direction: column;
        gap: 5px;
    }
    
    .label, .value {
        text-align: left;
        width: 100%;
    }
    
    .steps-timeline {
        grid-template-columns: 1fr;
    }
}

@media print {
    .action-buttons,
    .support-info {
        display: none;
    }
    
    .order-success-content {
        box-shadow: none;
    }
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>