<?php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'ct204485_deli');
define('DB_USER', 'ct204485_deli');
define('DB_PASS', 'eRS5jWzZ');
?>